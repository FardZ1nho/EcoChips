package upc.edu.pe.ecochips.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import upc.edu.pe.ecochips.DTOs.SoporteSolicitudDTO;
import upc.edu.pe.ecochips.Entities.SoporteSolicitud;
import upc.edu.pe.ecochips.Entities.Usuario;
import upc.edu.pe.ecochips.Repositories.IUserRepository;
import upc.edu.pe.ecochips.ServiceInterfaces.ISoporteSolicitudService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/soporte")
public class SoporteSolicitudController {
    @Autowired
    private ISoporteSolicitudService sR;

    @Autowired
    private IUserRepository usuarioRepository;

    @GetMapping
    public List<SoporteSolicitudDTO> listar() {
        return sR.list().stream().map(this::convertirADTO).collect(Collectors.toList());
    }

    @PostMapping
    public ResponseEntity<String> insertar(@RequestBody SoporteSolicitudDTO dto) {
        try {
            ModelMapper m = new ModelMapper();
            SoporteSolicitud so = m.map(dto, SoporteSolicitud.class);
            if (dto.getIdUsuario() != 0) {
                Usuario usuario = usuarioRepository.findById(dto.getIdUsuario()).orElse(null);
                if (usuario != null) {
                    so.setUsuario(usuario);
                } else {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                            .body("No existe un usuario con el ID: " + dto.getIdUsuario());
                }
            }

            sR.insert(so);
            return ResponseEntity.ok("Solicitud registrada correctamente");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al registrar solicitud: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        SoporteSolicitud r = sR.listID(id);
        if (r == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe una solicitud con el ID " + id);
        }
        SoporteSolicitudDTO dto = convertirADTO(r);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        SoporteSolicitud r = sR.listID(id);
        if (r == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro con el ID " + id);
        }
        sR.delete(id);
        return ResponseEntity.ok("Registro con Id " + id + " eliminado correctamente");
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody SoporteSolicitudDTO dto) {
        SoporteSolicitud existente = sR.listID(dto.getIdSoporteSolicitud());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe un registro con el ID " + dto.getIdSoporteSolicitud());
        }

        try {
            ModelMapper m = new ModelMapper();
            SoporteSolicitud r = m.map(dto, SoporteSolicitud.class);

            if (dto.getIdUsuario() != 0) {
                Usuario usuario = usuarioRepository.findById(dto.getIdUsuario()).orElse(null);
                if (usuario != null) {
                    r.setUsuario(usuario);
                }
            } else {
                // Mantener el usuario original si no se especifica uno nuevo
                r.setUsuario(existente.getUsuario());
            }

            sR.update(r);
            return ResponseEntity.ok("Registro con Id " + dto.getIdSoporteSolicitud() + " modificado correctamente");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al modificar solicitud: " + e.getMessage());
        }
    }

    @GetMapping("/buscar/{titulo}")
    public List<SoporteSolicitudDTO> listarBuscar(@PathVariable("titulo") String titulo) {
        return sR.buscarSoporteSolicitud(titulo).stream().map(this::convertirADTO).collect(Collectors.toList());
    }

    @GetMapping("/estado/{estado}")
    public List<SoporteSolicitudDTO> listarPorEstado(@PathVariable("estado") String estado) {
        return sR.listarPorEstado(estado).stream().map(this::convertirADTO).collect(Collectors.toList());
    }

    private SoporteSolicitudDTO convertirADTO(SoporteSolicitud solicitud) {
        SoporteSolicitudDTO dto = new SoporteSolicitudDTO();
        dto.setIdSoporteSolicitud(solicitud.getIdSoporteSolicitud());
        dto.setTitulo(solicitud.getTitulo());
        dto.setDescripcion(solicitud.getDescripcion());
        dto.setFecha(solicitud.getFecha());
        dto.setEstado(solicitud.getEstado());

        if (solicitud.getUsuario() != null) {
            dto.setIdUsuario(solicitud.getUsuario().getIdUsuario());
        }

        return dto;
    }
}