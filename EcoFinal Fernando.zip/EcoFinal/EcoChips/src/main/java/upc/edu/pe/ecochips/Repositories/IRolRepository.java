package upc.edu.pe.ecochips.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import upc.edu.pe.ecochips.Entities.Rol;

import java.util.List;

@Repository
public interface IRolRepository extends JpaRepository<Rol, Integer> {

    Rol findByNombre(String nombre);

    List<Rol> findByNombreContaining(String nombre);

    @Query("SELECT r FROM Rol r WHERE r.nombre LIKE %:nombre%")
    List<Rol> buscarR(@Param("nombre") String nombre);

    List<Rol> findByNombreContainingIgnoreCase(String nombre);
}