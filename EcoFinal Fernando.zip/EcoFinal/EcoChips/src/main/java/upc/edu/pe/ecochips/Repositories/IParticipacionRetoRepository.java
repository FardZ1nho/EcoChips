package upc.edu.pe.ecochips.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import upc.edu.pe.ecochips.Entities.ParticipacionReto;

import java.util.List;

@Repository
public interface IParticipacionRetoRepository extends JpaRepository<ParticipacionReto, Integer> {

    @Query("SELECT pr FROM ParticipacionReto pr WHERE pr.usuario.idUsuario = :idUsuario")
    List<ParticipacionReto> findByUsuarioId(@Param("idUsuario") Integer idUsuario);

    @Query("SELECT COUNT(pr) FROM ParticipacionReto pr WHERE pr.reto.idReto = :idReto")
    long countByRetoId(@Param("idReto") Integer idReto);
}