package upc.edu.pe.ecochips.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import upc.edu.pe.ecochips.Entities.ParticipacionReto;
import upc.edu.pe.ecochips.Entities.Reto;
import upc.edu.pe.ecochips.Entities.Usuario;
import upc.edu.pe.ecochips.Repositories.IParticipacionRetoRepository;
import upc.edu.pe.ecochips.Repositories.IRetoRepository;
import upc.edu.pe.ecochips.Repositories.IUserRepository;
import upc.edu.pe.ecochips.ServiceInterfaces.IParticipacionRetoService;
import upc.edu.pe.ecochips.ServiceInterfaces.IProgresoService;

import java.util.List;

@Service
public class ParticipacionRetoServiceImplements implements IParticipacionRetoService {

    @Autowired
    private IParticipacionRetoRepository prR;

    @Autowired
    private IUserRepository uR;

    @Autowired
    private IRetoRepository rR;

    @Autowired
    private IProgresoService pS;

    @Override
    public List<ParticipacionReto> list() {
        return prR.findAll();
    }

    @Override
    public void insert(ParticipacionReto participacionReto) {
        prR.save(participacionReto);
    }

    @Override
    public ParticipacionReto listId(int id) {
        return prR.findById(id).orElse(null);
    }

    @Override
    public void update(ParticipacionReto participacionReto) {
        prR.save(participacionReto);
    }

    @Override
    public void delete(int id) {
        prR.deleteById(id);
    }

    @Override
    public List<ParticipacionReto> listarPorUsuario(Integer idUsuario) {
        return prR.findByUsuarioId(idUsuario);
    }

    @Override
    public long contarParticipantesPorReto(Integer idReto) {
        return prR.countByRetoId(idReto);
    }

    @Override
    public String completarReto(Integer idUsuario, Integer idReto) {
        Usuario usuario = uR.findById(idUsuario).orElse(null);
        Reto reto = rR.findById(idReto).orElse(null);

        if (usuario == null) {
            return "Usuario no encontrado";
        }
        if (reto == null) {
            return "Reto no encontrado";
        }

        // Verificar si ya participó en el reto
        List<ParticipacionReto> participaciones = prR.findByUsuarioId(idUsuario);
        boolean yaParticipo = participaciones.stream()
                .anyMatch(pr -> pr.getReto().getIdReto() == idReto);

        if (yaParticipo) {
            return "El usuario ya participó en este reto";
        }

        ParticipacionReto participacion = new ParticipacionReto();
        participacion.setUsuario(usuario);
        participacion.setReto(reto);
        participacion.setCompletado(true);
        prR.save(participacion);

        usuario.setCanjesDisponibles(usuario.getCanjesDisponibles() + 1);
        uR.save(usuario);

        return "Reto completado exitosamente. Se ha agregado 1 canje disponible.";
    }
}