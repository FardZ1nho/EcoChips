package upc.edu.pe.ecochips.DTOs;

public class ParticipacionRetoDTO {
    private int idParticipacion;
    private int idUsuario;
    private int idReto;
    private boolean completado;

    public ParticipacionRetoDTO() {
    }

    public ParticipacionRetoDTO(int idParticipacion, int idUsuario, int idReto, boolean completado) {
        this.idParticipacion = idParticipacion;
        this.idUsuario = idUsuario;
        this.idReto = idReto;
        this.completado = completado;
    }

    public int getIdParticipacion() {
        return idParticipacion;
    }

    public void setIdParticipacion(int idParticipacion) {
        this.idParticipacion = idParticipacion;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdReto() {
        return idReto;
    }

    public void setIdReto(int idReto) {
        this.idReto = idReto;
    }

    public boolean isCompletado() {
        return completado;
    }

    public void setCompletado(boolean completado) {
        this.completado = completado;
    }
}