package upc.edu.pe.ecochips.ServiceInterfaces;

import upc.edu.pe.ecochips.Entities.Usuario;

import java.util.List;

public interface IUserService {
    List<Usuario> list();
    void insert(Usuario usuario);
    Usuario listId(int id);
    void update(Usuario usuario);
    void delete(int id);
    Usuario findByCorreo(String correo);
    Usuario findOneByNombre(String nombre);
    List<Usuario> findByNivel(int nivel);
    List<Object[]> obtenerDistribucionParticipantesPorGenero();

}