package upc.edu.pe.ecochips.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import upc.edu.pe.ecochips.Entities.RegistroTransporte;
import upc.edu.pe.ecochips.Entities.Transporte;
import upc.edu.pe.ecochips.Repositories.IRegistroTransporteRepository;
import upc.edu.pe.ecochips.Repositories.ITransporteRepository;
import upc.edu.pe.ecochips.ServiceInterfaces.IRegistroTransporteService;
import upc.edu.pe.ecochips.ServiceInterfaces.IProgresoService;

import java.util.List;

@Service
public class RegistroTransporteServiceImplements implements IRegistroTransporteService {

    @Autowired
    private IRegistroTransporteRepository rtR;

    @Autowired
    private ITransporteRepository tR;

    @Autowired
    private IProgresoService pS;

    @Override
    public List<RegistroTransporte> list() {
        return rtR.findAll();
    }

    @Override
    public void insert(RegistroTransporte registroTransporte) {
        Transporte transporte = tR.findById(registroTransporte.getIdTransporte()).orElse(null);
        if (transporte != null) {
            // Calcular CO2 emitido: distancia_km * factor_co2
            Double co2Emitido = registroTransporte.getDistanciaKm() * transporte.getFactorCo2();
            registroTransporte.setCo2Emitido(co2Emitido);
        }

        rtR.save(registroTransporte);

        // Agregar 1 punto de progreso al usuario
        pS.agregarPuntos(registroTransporte.getIdUsuario(), 1);
    }

    @Override
    public RegistroTransporte listId(int id) {
        return rtR.findById(id).orElse(null);
    }

    @Override
    public void update(RegistroTransporte registroTransporte) {
        // Buscar el registro existente
        RegistroTransporte existingRegistro = rtR.findById(registroTransporte.getIdRegistroTransporte()).orElse(null);
        if (existingRegistro != null) {
            // Si cambió el transporte o la distancia, recalcular CO2
            if (!existingRegistro.getIdTransporte().equals(registroTransporte.getIdTransporte()) ||
                    !existingRegistro.getDistanciaKm().equals(registroTransporte.getDistanciaKm())) {

                Transporte transporte = tR.findById(registroTransporte.getIdTransporte()).orElse(null);
                if (transporte != null) {
                    Double co2Emitido = registroTransporte.getDistanciaKm() * transporte.getFactorCo2();
                    registroTransporte.setCo2Emitido(co2Emitido);
                }
            } else {
                // Mantener el mismo CO2 emitido
                registroTransporte.setCo2Emitido(existingRegistro.getCo2Emitido());
            }
        }
        rtR.save(registroTransporte);
    }

    @Override
    public void delete(int id) {
        rtR.deleteById(id);
    }

    @Override
    public List<RegistroTransporte> listarPorUsuario(Integer idUsuario) {
        return rtR.findByIdUsuario(idUsuario);
    }
}