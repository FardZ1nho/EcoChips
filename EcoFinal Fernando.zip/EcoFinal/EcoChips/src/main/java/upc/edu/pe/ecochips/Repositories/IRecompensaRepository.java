package upc.edu.pe.ecochips.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import upc.edu.pe.ecochips.Entities.Recompensa;

import java.util.List;

@Repository
public interface IRecompensaRepository extends JpaRepository<Recompensa, Integer> {

    @Query("SELECT r FROM Recompensa r WHERE r.costoCanjes = :costoCanjes")
    List<Recompensa> findByCostoCanjes(@Param("costoCanjes") int costoCanjes);

    @Query("SELECT r FROM Recompensa r WHERE r.tituloRecompensa LIKE %:titulo%")
    List<Recompensa> findByTituloContaining(@Param("titulo") String titulo);
}