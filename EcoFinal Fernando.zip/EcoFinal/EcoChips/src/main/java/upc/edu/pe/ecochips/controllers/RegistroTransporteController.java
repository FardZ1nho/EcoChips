package upc.edu.pe.ecochips.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import upc.edu.pe.ecochips.DTOs.RegistroTransporteDTO;
import upc.edu.pe.ecochips.Entities.RegistroTransporte;
import upc.edu.pe.ecochips.ServiceInterfaces.IRegistroTransporteService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/registrostransporte")
public class RegistroTransporteController {

    @Autowired
    private IRegistroTransporteService rtS;

    @GetMapping
    public List<RegistroTransporteDTO> listar() {
        return rtS.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y, RegistroTransporteDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarPorId(@PathVariable("id") int id) {
        RegistroTransporte registro = rtS.listId(id);
        if (registro == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro de transporte con el ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        RegistroTransporteDTO dto = m.map(registro, RegistroTransporteDTO.class);
        return ResponseEntity.ok(dto);
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<RegistroTransporteDTO> listarPorUsuario(@PathVariable("idUsuario") Integer idUsuario) {
        return rtS.listarPorUsuario(idUsuario).stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y, RegistroTransporteDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public String insertar(@RequestBody RegistroTransporteDTO dto) {
        ModelMapper m = new ModelMapper();
        RegistroTransporte registro = m.map(dto, RegistroTransporte.class);
        rtS.insert(registro);
        return "Registro de transporte guardado correctamente";
    }

    @PutMapping
    public ResponseEntity<String> actualizar(@RequestBody RegistroTransporteDTO dto) {
        RegistroTransporte existe = rtS.listId(dto.getIdRegistroTransporte());
        if (existe == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe un registro con el ID: " + dto.getIdRegistroTransporte());
        }
        ModelMapper m = new ModelMapper();
        RegistroTransporte registro = m.map(dto, RegistroTransporte.class);
        rtS.update(registro);
        return ResponseEntity.ok("Registro de transporte con ID " + dto.getIdRegistroTransporte() + " modificado correctamente.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") int id) {
        RegistroTransporte registro = rtS.listId(id);
        if (registro == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro de transporte con el ID: " + id);
        }
        rtS.delete(id);
        return ResponseEntity.ok("Registro de transporte con ID " + id + " eliminado correctamente.");
    }
}