package upc.edu.pe.ecochips.Entities;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "progreso")
public class Progreso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idProgreso;

    @Column(name = "id_usuario", nullable = false)
    private Integer idUsuario;

    @Column(name = "puntos", nullable = false)
    private Integer puntos;

    @Column(name = "estado", length = 50, nullable = false)
    private String estado;

    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    public Progreso() {
        this.puntos = 0;
        this.estado = "Activo";
        this.fecha = LocalDate.now();
    }

    public Progreso(Integer idProgreso, Integer idUsuario, Integer puntos, String estado, LocalDate fecha) {
        this.idProgreso = idProgreso;
        this.idUsuario = idUsuario;
        this.puntos = puntos;
        this.estado = estado;
        this.fecha = fecha;
    }

    public Integer getIdProgreso() {
        return idProgreso;
    }

    public void setIdProgreso(Integer idProgreso) {
        this.idProgreso = idProgreso;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Integer getPuntos() {
        return puntos;
    }

    public void setPuntos(Integer puntos) {
        this.puntos = puntos;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
}