package upc.edu.pe.ecochips.ServiceInterfaces;

import upc.edu.pe.ecochips.Entities.Progreso;
import java.util.List;

public interface IProgresoService {
    List<Progreso> list();
    void insert(Progreso progreso);
    Progreso listId(int id);
    void update(Progreso progreso);
    void delete(int id);

    Progreso obtenerProgresoPorUsuario(Integer idUsuario);
    void agregarPuntos(Integer idUsuario, Integer puntos);
    void cambiarEstado(Integer idUsuario, String estado);
}