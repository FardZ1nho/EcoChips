package upc.edu.pe.ecochips.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import upc.edu.pe.ecochips.Entities.Usuario;
import upc.edu.pe.ecochips.Repositories.IUserRepository;
import upc.edu.pe.ecochips.ServiceInterfaces.IUserService;

import java.util.List;

@Service
public class UserServiceImplements implements IUserService
{

    @Autowired
    private IUserRepository uR;

    @Override
    public List<Usuario> list() {
        return uR.findAll();
    }

    @Override
    public void insert(Usuario usuario) {
        uR.save(usuario);
    }

    @Override
    public Usuario listId(int id) {
        return uR.findById(id).orElse(null);
    }

    @Override
    public void update(Usuario usuario) {
        uR.save(usuario);
    }

    @Override
    public void delete(int id) {
        uR.deleteById(id);
    }

    @Override
    public Usuario findByCorreo(String correo) {
        return uR.findByCorreo(correo);
    }

    @Override
    public Usuario findOneByNombre(String nombre) {
        return uR.findOneByNombre(nombre);
    }

    @Override
    public List<Usuario> findByNivel(int nivel) {
        return uR.findByNivel(nivel);
    }

    @Override
    public List<Object[]> obtenerDistribucionParticipantesPorGenero() {
        return uR.obtenerDistribucionParticipantesPorGenero();
    }
}
