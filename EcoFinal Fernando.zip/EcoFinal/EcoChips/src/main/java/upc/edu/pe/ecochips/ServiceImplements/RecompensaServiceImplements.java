package upc.edu.pe.ecochips.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import upc.edu.pe.ecochips.Entities.Recompensa;
import upc.edu.pe.ecochips.Repositories.IRecompensaRepository;
import upc.edu.pe.ecochips.ServiceInterfaces.IRecompensaService;

import java.util.List;

@Service
public class RecompensaServiceImplements implements IRecompensaService {

    @Autowired
    private IRecompensaRepository rR;

    @Override
    public List<Recompensa> list() {
        return rR.findAll();
    }

    @Override
    public void insert(Recompensa recompensa) {
        rR.save(recompensa);
    }

    @Override
    public Recompensa listId(int id) {
        return rR.findById(id).orElse(null);
    }

    @Override
    public void update(Recompensa recompensa) {
        rR.save(recompensa);
    }

    @Override
    public void delete(int id) {
        rR.deleteById(id);
    }

    @Override
    public List<Recompensa> buscarPorCostoCanjes(int costoCanjes) {
        return rR.findByCostoCanjes(costoCanjes);
    }

    @Override
    public List<Recompensa> buscarPorTitulo(String titulo) {
        return rR.findByTituloContaining(titulo);
    }
}