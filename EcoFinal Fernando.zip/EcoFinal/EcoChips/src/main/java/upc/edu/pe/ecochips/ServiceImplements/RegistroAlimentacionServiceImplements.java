package upc.edu.pe.ecochips.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import upc.edu.pe.ecochips.Entities.Alimento;
import upc.edu.pe.ecochips.Entities.RegistroAlimentacion;
import upc.edu.pe.ecochips.Repositories.IAlimentoRepository;
import upc.edu.pe.ecochips.Repositories.IRegistroAlimentacionRepository;
import upc.edu.pe.ecochips.ServiceInterfaces.IRegistroAlimentacionService;
import upc.edu.pe.ecochips.ServiceInterfaces.IProgresoService;

import java.util.List;

@Service
public class RegistroAlimentacionServiceImplements implements IRegistroAlimentacionService {

    @Autowired
    private IRegistroAlimentacionRepository raR;

    @Autowired
    private IAlimentoRepository aR;

    @Autowired
    private IProgresoService pS;

    @Override
    public List<RegistroAlimentacion> list() {
        return raR.findAll();
    }

    @Override
    public void insert(RegistroAlimentacion registroAlimentacion) {
        Alimento alimento = aR.findById(registroAlimentacion.getIdAlimento()).orElse(null);
        if (alimento != null) {
            // Calcular CO2 emitido: porciones * co2_porcion
            Double co2Emitido = registroAlimentacion.getPorciones() * alimento.getCo2Porcion();
            registroAlimentacion.setCo2Emitido(co2Emitido);
        }

        raR.save(registroAlimentacion);

        // Agregar 1 punto de progreso al usuario
        pS.agregarPuntos(registroAlimentacion.getIdUsuario(), 1);
    }

    @Override
    public RegistroAlimentacion listId(int id) {
        return raR.findById(id).orElse(null);
    }

    @Override
    public void update(RegistroAlimentacion registroAlimentacion) {
        RegistroAlimentacion existingRegistro = raR.findById(registroAlimentacion.getIdRegistroAlimentacion()).orElse(null);
        if (existingRegistro != null) {
            if (!existingRegistro.getIdAlimento().equals(registroAlimentacion.getIdAlimento()) ||
                    !existingRegistro.getPorciones().equals(registroAlimentacion.getPorciones())) {

                Alimento alimento = aR.findById(registroAlimentacion.getIdAlimento()).orElse(null);
                if (alimento != null) {
                    Double co2Emitido = registroAlimentacion.getPorciones() * alimento.getCo2Porcion();
                    registroAlimentacion.setCo2Emitido(co2Emitido);
                }
            } else {
                registroAlimentacion.setCo2Emitido(existingRegistro.getCo2Emitido());
            }
        }
        raR.save(registroAlimentacion);
    }

    @Override
    public void delete(int id) {
        raR.deleteById(id);
    }

    @Override
    public List<RegistroAlimentacion> listarPorUsuario(Integer idUsuario) {
        return raR.findByIdUsuario(idUsuario);
    }

}