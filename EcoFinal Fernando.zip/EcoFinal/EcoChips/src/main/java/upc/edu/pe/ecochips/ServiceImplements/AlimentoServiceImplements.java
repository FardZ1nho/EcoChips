package upc.edu.pe.ecochips.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import upc.edu.pe.ecochips.Entities.Alimento;
import upc.edu.pe.ecochips.Repositories.IAlimentoRepository;
import upc.edu.pe.ecochips.ServiceInterfaces.IAlimentoService;

import java.util.List;

@Service
public class AlimentoServiceImplements implements IAlimentoService {

    @Autowired
    private IAlimentoRepository aR;

    @Override
    public List<Alimento> list() {
        return aR.findAll();
    }

    @Override
    public void insert(Alimento alimento) {
        aR.save(alimento);
    }

    @Override
    public Alimento listId(int id) {
        return aR.findById(id).orElse(null);
    }

    @Override
    public void update(Alimento alimento) {
        aR.save(alimento);
    }

    @Override
    public void delete(int id) {
        aR.deleteById(id);
    }
}