package upc.edu.pe.ecochips.Entities;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "registro_transporte")
public class RegistroTransporte {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idRegistroTransporte;

    @Column(name = "id_usuario", nullable = false)
    private Integer idUsuario;

    @Column(name = "id_transporte", nullable = false)
    private Integer idTransporte;

    @Column(name = "distancia_km", nullable = false)
    private Double distanciaKm; // Quitamos precision y scale

    @Column(name = "co2_emitido", nullable = false)
    private Double co2Emitido; // Quitamos precision y scale

    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    public RegistroTransporte() {
    }

    public RegistroTransporte(Integer idRegistroTransporte, Integer idUsuario, Integer idTransporte,
                              Double distanciaKm, Double co2Emitido, LocalDate fecha) {
        this.idRegistroTransporte = idRegistroTransporte;
        this.idUsuario = idUsuario;
        this.idTransporte = idTransporte;
        this.distanciaKm = distanciaKm;
        this.co2Emitido = co2Emitido;
        this.fecha = fecha;
    }

    public Integer getIdRegistroTransporte() {
        return idRegistroTransporte;
    }

    public void setIdRegistroTransporte(Integer idRegistroTransporte) {
        this.idRegistroTransporte = idRegistroTransporte;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Integer getIdTransporte() {
        return idTransporte;
    }

    public void setIdTransporte(Integer idTransporte) {
        this.idTransporte = idTransporte;
    }

    public Double getDistanciaKm() {
        return distanciaKm;
    }

    public void setDistanciaKm(Double distanciaKm) {
        this.distanciaKm = distanciaKm;
    }

    public Double getCo2Emitido() {
        return co2Emitido;
    }

    public void setCo2Emitido(Double co2Emitido) {
        this.co2Emitido = co2Emitido;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
}