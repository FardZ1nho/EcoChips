package upc.edu.pe.ecochips.Entities;
import jakarta.persistence.*;

@Entity
@Table(name = "ParticipacionReto")
public class ParticipacionReto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idParticipacion;

    @ManyToOne
    @JoinColumn(name = "idUsuario", nullable = false)
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "idReto", nullable = false)
    private Reto reto;

    @Column(name = "completado", nullable = false)
    private boolean completado;

    public ParticipacionReto() {}

    public ParticipacionReto(int idParticipacion, Usuario usuario, Reto reto, boolean completado) {
        this.idParticipacion = idParticipacion;
        this.usuario = usuario;
        this.reto = reto;
        this.completado = completado;
    }

    public int getIdParticipacion() {
        return idParticipacion;
    }

    public void setIdParticipacion(int idParticipacion) {
        this.idParticipacion = idParticipacion;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Reto getReto() {
        return reto;
    }

    public void setReto(Reto reto) {
        this.reto = reto;
    }

    public boolean isCompletado() {
        return completado;
    }

    public void setCompletado(boolean completado) {
        this.completado = completado;
    }
}