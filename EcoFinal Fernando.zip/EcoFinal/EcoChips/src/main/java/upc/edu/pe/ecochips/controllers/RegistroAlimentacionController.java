package upc.edu.pe.ecochips.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import upc.edu.pe.ecochips.DTOs.RegistroAlimentacionDTO;
import upc.edu.pe.ecochips.Entities.RegistroAlimentacion;
import upc.edu.pe.ecochips.ServiceInterfaces.IRegistroAlimentacionService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/registrosalimentacion")
public class RegistroAlimentacionController {

    @Autowired
    private IRegistroAlimentacionService raS;

    @GetMapping
    public List<RegistroAlimentacionDTO> listar() {
        return raS.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y, RegistroAlimentacionDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarPorId(@PathVariable("id") int id) {
        RegistroAlimentacion registro = raS.listId(id);
        if (registro == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro de alimentación con el ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        RegistroAlimentacionDTO dto = m.map(registro, RegistroAlimentacionDTO.class);
        return ResponseEntity.ok(dto);
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<RegistroAlimentacionDTO> listarPorUsuario(@PathVariable("idUsuario") Integer idUsuario) {
        return raS.listarPorUsuario(idUsuario).stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y, RegistroAlimentacionDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public String insertar(@RequestBody RegistroAlimentacionDTO dto) {
        ModelMapper m = new ModelMapper();
        RegistroAlimentacion registro = m.map(dto, RegistroAlimentacion.class);
        raS.insert(registro);
        return "Registro de alimentación guardado correctamente";
    }

    @PutMapping
    public ResponseEntity<String> actualizar(@RequestBody RegistroAlimentacionDTO dto) {
        RegistroAlimentacion existe = raS.listId(dto.getIdRegistroAlimentacion());
        if (existe == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe un registro con el ID: " + dto.getIdRegistroAlimentacion());
        }
        ModelMapper m = new ModelMapper();
        RegistroAlimentacion registro = m.map(dto, RegistroAlimentacion.class);
        raS.update(registro);
        return ResponseEntity.ok("Registro de alimentación con ID " + dto.getIdRegistroAlimentacion() + " modificado correctamente.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") int id) {
        RegistroAlimentacion registro = raS.listId(id);
        if (registro == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro de alimentación con el ID: " + id);
        }
        raS.delete(id);
        return ResponseEntity.ok("Registro de alimentación con ID " + id + " eliminado correctamente.");
    }
}