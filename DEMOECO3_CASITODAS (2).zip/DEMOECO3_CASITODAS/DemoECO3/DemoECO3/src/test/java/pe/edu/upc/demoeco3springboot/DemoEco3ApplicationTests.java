package pe.edu.upc.demoeco3springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEco3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
