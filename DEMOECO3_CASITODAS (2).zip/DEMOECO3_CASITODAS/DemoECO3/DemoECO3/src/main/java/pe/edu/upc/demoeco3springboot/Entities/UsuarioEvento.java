package pe.edu.upc.demoeco3springboot.Entities;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity

@Table(name = "UsuarioEvento")

public class UsuarioEvento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idUsuarioEvento;

    @ManyToOne
    @JoinColumn(name = "idUsuario", nullable = false)
    private UsuarioRecomendacion usuario;

    @ManyToOne
    @JoinColumn(name = "idEvento", nullable = false)
    private Evento evento;



    @Column(name = "fechaRegistro", nullable = false)
    private LocalDate fechaRegistro;

    public UsuarioEvento() {}

    public int getIdUsuarioEvento() {
        return idUsuarioEvento;
    }

    public void setIdUsuarioEvento(int idUsuarioEvento) {
        this.idUsuarioEvento = idUsuarioEvento;
    }

    public UsuarioRecomendacion getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioRecomendacion usuario) {
        this.usuario = usuario;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public UsuarioEvento(int idUsuarioEvento, UsuarioRecomendacion usuario, Evento evento, LocalDate fechaRegistro) {
        this.idUsuarioEvento = idUsuarioEvento;
        this.usuario = usuario;
        this.evento = evento;
        this.fechaRegistro = fechaRegistro;

    }
}
