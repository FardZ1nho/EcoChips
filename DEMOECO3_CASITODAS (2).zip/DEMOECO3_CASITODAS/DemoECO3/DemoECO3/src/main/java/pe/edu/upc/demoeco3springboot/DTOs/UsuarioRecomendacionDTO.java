package pe.edu.upc.demoeco3springboot.DTOs;

import pe.edu.upc.demoeco3springboot.Entities.UsuarioRecomendacion;

import java.time.LocalDate;

public class UsuarioRecomendacionDTO {

    private int idUsuarioRecomendacion;
    private UsuarioRecomendacion usuario;
    private Recomendacion recomendacion;
    private LocalDate fechaRecomendacion;

    public int getIdUsuarioRecomendacion() {
        return idUsuarioRecomendacion;
    }

    public void setIdUsuarioRecomendacion(int idUsuarioRecomendacion) {
        this.idUsuarioRecomendacion = idUsuarioRecomendacion;
    }

    public UsuarioRecomendacion getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioRecomendacion usuario) {
        this.usuario = usuario;
    }

    public Recomendacion getRecomendacion() {
        return recomendacion;
    }

    public void setRecomendacion(Recomendacion recomendacion) {
        this.recomendacion = recomendacion;
    }

    public LocalDate getFechaRecomendacion() {
        return fechaRecomendacion;
    }

    public void setFechaRecomendacion(LocalDate fechaRecomendacion) {
        this.fechaRecomendacion = fechaRecomendacion;
    }
}
