package pe.edu.upc.demoeco3springboot.ServiceInterface;

import pe.edu.upc.demoeco3springboot.Entities.UsuarioEvento;

import java.util.List;

public interface IUsuarioEventoService {

    public List<UsuarioEvento> list();
    public void insert(UsuarioEvento usuarioEvento);
}
