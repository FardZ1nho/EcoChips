package pe.edu.upc.demoeco3springboot.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.demoeco3springboot.Entities.UsuarioEvento;
import pe.edu.upc.demoeco3springboot.Repositories.IUsuarioEventoRepositoy;
import pe.edu.upc.demoeco3springboot.ServiceInterface.IUsuarioEventoService;

import java.util.List;

@Service


public class UsuarioEventoImplement implements IUsuarioEventoService{

    @Autowired
    private IUsuarioEventoRepositoy ueS;

    @Override
    public List<UsuarioEvento> list() {return ueS.findAll();}

    @Override
    public void insert(UsuarioEvento usuarioEvento) {ueS.save(usuarioEvento);}
}
