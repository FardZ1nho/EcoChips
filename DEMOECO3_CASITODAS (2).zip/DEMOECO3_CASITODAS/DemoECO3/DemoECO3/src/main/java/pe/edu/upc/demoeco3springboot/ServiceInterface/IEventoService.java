package pe.edu.upc.demoeco3springboot.ServiceInterface;

import pe.edu.upc.demoeco3springboot.Entities.Evento;
import pe.edu.upc.demoeco3springboot.Entities.Evento;


import java.util.Collection;
import java.util.List;


public interface IEventoService {

    public List<Evento> list();
    public Evento listId(int id);
    public void insert(Evento evento);
    void delete(int id);
}
