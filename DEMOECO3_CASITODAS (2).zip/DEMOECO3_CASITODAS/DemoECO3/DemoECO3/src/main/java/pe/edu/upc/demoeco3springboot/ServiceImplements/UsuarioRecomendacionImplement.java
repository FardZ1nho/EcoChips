package pe.edu.upc.demoeco3springboot.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.demoeco3springboot.Repositories.IUsuarioRecomendacionRepository;
import pe.edu.upc.demoeco3springboot.ServiceInterface.IUsuarioRecomendacionService;

import java.util.List;

@Service

public class UsuarioRecomendacionImplement  implements IUsuarioRecomendacionService {

    @Autowired
    private IUsuarioRecomendacionRepository urS;

    @Override
    public List<UsuarioRecomendacion> list() {return urS.findAll();}

    @Override
    public void insert(UsuarioRecomendacion usuarioRecomendacion) {urS.save(usuarioRecomendacion);}


}
