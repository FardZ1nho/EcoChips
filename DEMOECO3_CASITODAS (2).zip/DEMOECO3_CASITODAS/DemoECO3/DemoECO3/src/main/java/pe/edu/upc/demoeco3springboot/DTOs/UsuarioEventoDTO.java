package pe.edu.upc.demoeco3springboot.DTOs;

import pe.edu.upc.demoeco3springboot.Entities.Evento;
import pe.edu.upc.demoeco3springboot.Entities.UsuarioRecomendacion;

import java.time.LocalDate;


public class UsuarioEventoDTO {

    private int idUsuarioEvento;
    private UsuarioRecomendacion usuario;
    private Evento evento;
    private LocalDate fechaRegistro;

    public int getIdUsuarioEvento() {
        return idUsuarioEvento;
    }

    public void setIdUsuarioEvento(int idUsuarioEvento) {
        this.idUsuarioEvento = idUsuarioEvento;
    }

    public UsuarioRecomendacion getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioRecomendacion usuario) {
        this.usuario = usuario;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
}
