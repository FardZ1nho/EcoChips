package pe.edu.upc.demoeco3springboot.DTOs;

import pe.edu.upc.demoeco3springboot.Entities.UsuarioRecomendacion;
import pe.edu.upc.demoeco3springboot.Entities.Evento;

import java.time.LocalDateTime;

public class NotificacionDTO {

    private int idNotificacion;
    private UsuarioRecomendacion usuario;
    private Actividad actividad;
    private Reto reto;
    private Evento evento;
    private String tipo;
    private String titulo;
    private String mensaje;
    private LocalDateTime fechaCrea;

    public int getIdNotificacion() {
        return idNotificacion;
    }

    public void setIdNotificacion(int idNotificacion) {
        this.idNotificacion = idNotificacion;
    }

    public UsuarioRecomendacion getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioRecomendacion usuario) {
        this.usuario = usuario;
    }

    public Actividad getActividad() {
        return actividad;
    }

    public void setActividad(Actividad actividad) {
        this.actividad = actividad;
    }

    public Reto getReto() {
        return reto;
    }

    public void setReto(Reto reto) {
        this.reto = reto;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public LocalDateTime getFechaCrea() {
        return fechaCrea;
    }

    public void setFechaCrea(LocalDateTime fechaCrea) {
        this.fechaCrea = fechaCrea;
    }
}
