package pe.edu.upc.demoeco3springboot.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.demoeco3springboot.DTOs.UsuarioEventoDTO;

import pe.edu.upc.demoeco3springboot.Entities.UsuarioEvento;

import pe.edu.upc.demoeco3springboot.ServiceInterface.IUsuarioEventoService;


import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/usuario-evento")

public class UsuarioEventoController {

    @Autowired
    private IUsuarioEventoService ueS;

    @PostMapping
    public void insert(@RequestBody UsuarioEventoDTO dto)
    {
        ModelMapper m = new ModelMapper();
        UsuarioEvento uh =m.map(dto,UsuarioEvento.class);
        ueS.insert(uh);
    }

    @GetMapping("/dtos")
    public List<UsuarioEventoDTO> list(){
        return ueS.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y,UsuarioEventoDTO.class);
        }).collect(Collectors.toList());
    }
}
