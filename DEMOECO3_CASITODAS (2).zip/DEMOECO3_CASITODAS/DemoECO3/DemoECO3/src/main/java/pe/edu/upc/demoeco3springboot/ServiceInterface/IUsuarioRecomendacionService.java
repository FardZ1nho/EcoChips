package pe.edu.upc.demoeco3springboot.ServiceInterface;

import java.util.List;

public interface IUsuarioRecomendacionService {


    public List<UsuarioRecomendacion> list();
    public void insert(UsuarioRecomendacion usuarioRecomendacion);

}
