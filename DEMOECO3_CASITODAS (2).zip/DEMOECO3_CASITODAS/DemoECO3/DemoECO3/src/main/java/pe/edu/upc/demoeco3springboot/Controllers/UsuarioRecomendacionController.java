package pe.edu.upc.demoeco3springboot.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.demoeco3springboot.DTOs.UsuarioRecomendacionDTO;

import pe.edu.upc.demoeco3springboot.ServiceInterface.IUsuarioRecomendacionService;

import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/usuario-recomendacion")

public class UsuarioRecomendacionController {

    @Autowired
    private IUsuarioRecomendacionService urS;

    @PostMapping
    public void insert(@RequestBody UsuarioRecomendacionDTO dto)
    {
        ModelMapper m = new ModelMapper();
        UsuarioRecomendacion uh =m.map(dto,UsuarioRecomendacion.class);
        urS.insert(uh);
    }

    @GetMapping("/dtos")
    public List<UsuarioRecomendacionDTO> list(){
        return urS.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y,UsuarioRecomendacionDTO.class);
        }).collect(Collectors.toList());
    }
}
