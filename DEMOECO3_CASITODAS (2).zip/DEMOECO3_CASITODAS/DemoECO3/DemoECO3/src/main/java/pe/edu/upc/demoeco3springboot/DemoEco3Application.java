package pe.edu.upc.demoeco3springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoEco3Application {

    public static void main(String[] args) {
        SpringApplication.run(DemoEco3Application.class, args);
    }

}
