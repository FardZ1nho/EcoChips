package pe.edu.upc.demoeco3springboot.ServiceInterface;

import pe.edu.upc.demoeco3springboot.Entities.Notificacion;


import java.util.Collection;
import java.util.List;

public interface INotificacionService {

    public List<Notificacion> list();
    public Notificacion listId(int id);
    public void insert(Notificacion notificacion);
}
