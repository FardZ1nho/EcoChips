package pe.edu.upc.tabla_fernando;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TablaFernandoApplicationTests {

    @Test
    void contextLoads() {
    }

}
