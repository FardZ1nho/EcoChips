package pe.edu.upc.tabla_fernando.ServicesInterfaces;

import pe.edu.upc.tabla_fernando.Entities.Usuario;

import java.util.List;

public interface IUsuarioService {
    List<Usuario> list();

    void insert(Usuario usuario);

    Usuario listId(int id);

    void delete(int id);

    void update(Usuario usuario);

    List<Usuario> findByNivel(int nivel);
}
