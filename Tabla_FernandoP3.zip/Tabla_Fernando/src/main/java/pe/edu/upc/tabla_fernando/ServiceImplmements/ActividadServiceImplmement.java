package pe.edu.upc.tabla_fernando.ServiceImplmements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.tabla_fernando.Entities.Actividad;
import pe.edu.upc.tabla_fernando.Repositories.IActividadRepository;
import pe.edu.upc.tabla_fernando.ServicesInterfaces.IActividadService;

import java.util.List;

@Service
public class ActividadServiceImplmement implements IActividadService {
    @Autowired
    private IActividadRepository actividadRepo;

    @Override
    public List<Actividad> list() {return actividadRepo.findAll();}

    @Override
    public Actividad listId(int id) {return actividadRepo.findById(id).orElse(null);}

    @Override
    public void insert(Actividad actividad) {
        actividadRepo.save(actividad);
    }

    @Override
    public void update(Actividad actividad) { actividadRepo.save(actividad); }

    @Override
    public void delete(int id) {
        actividadRepo.deleteById(id);
    }

}
