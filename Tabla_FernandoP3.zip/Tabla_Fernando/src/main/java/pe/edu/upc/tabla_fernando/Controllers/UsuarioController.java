package pe.edu.upc.tabla_fernando.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.tabla_fernando.DTOs.UsuarioDTO;
import pe.edu.upc.tabla_fernando.DTOs.UsuarioNivelDTO;
import pe.edu.upc.tabla_fernando.Entities.Usuario;
import pe.edu.upc.tabla_fernando.Repositories.IProgresoRepository;
import pe.edu.upc.tabla_fernando.ServicesInterfaces.IUsuarioService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/Usuarios")
public class UsuarioController {
    @Autowired
    private IUsuarioService usuarioService;

    @Autowired
    private IProgresoRepository progresoRepo;

    @GetMapping
    public List<UsuarioDTO> listar() {
        return usuarioService.list().stream().map(y -> {
            ModelMapper m = new ModelMapper();
            return m.map(y, UsuarioDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody UsuarioDTO dto) {
        ModelMapper m = new ModelMapper();
        Usuario u = m.map(dto, Usuario.class);
        usuarioService.insert(u);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Usuario us = usuarioService.listId(id);
        if (us == null) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("El usuario no existe con ID " + id);
        }

        ModelMapper m = new ModelMapper();
        UsuarioDTO dto = m.map(us, UsuarioDTO.class);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        Usuario us = usuarioService.listId(id);
        if (us == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro con el ID " + id);
        }
        usuarioService.delete(id);
        return ResponseEntity.ok("Registro con ID " + id + " eliminado correctamente");
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody UsuarioDTO dto) {
        ModelMapper m = new ModelMapper();
        Usuario u = m.map(dto, Usuario.class);

        Usuario existente = usuarioService.listId(u.getIdUsuario());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe un registro con el ID " + u.getIdUsuario());
        }
        usuarioService.update(u);
        return ResponseEntity.ok("Registro con ID " + u.getIdUsuario() + " modificado correctamente");
    }

    @GetMapping("/nivel/{nivel}")
    public ResponseEntity<?> listarPorNivel(@PathVariable("nivel") int nivel) {
        List<Usuario> usuarios = usuarioService.findByNivel(nivel);

        if (usuarios.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existen usuarios con nivel " + nivel);
        }

        List<UsuarioDTO> listaDTO = usuarios.stream().map(u -> {
            ModelMapper m = new ModelMapper();
            return m.map(u, UsuarioDTO.class);
        }).collect(Collectors.toList());

        return ResponseEntity.ok(listaDTO);
    }

    @GetMapping("/resumen/nivel/{nivel}")
    public ResponseEntity<?> listarResumenPorNivel(@PathVariable("nivel") int nivel) {
        List<Usuario> usuarios = usuarioService.findByNivel(nivel);

        if (usuarios.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existen usuarios con nivel " + nivel);
        }

        List<UsuarioNivelDTO> listaDTO = usuarios.stream().map(u -> {
            UsuarioNivelDTO dto = new UsuarioNivelDTO();
            dto.setNombre(u.getNombre());
            dto.setNivel(u.getNivel());

            int puntosTotales = progresoRepo.sumarPuntosPorUsuario(u.getIdUsuario());
            dto.setPuntos(puntosTotales);

            return dto;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(listaDTO);
    }
}
