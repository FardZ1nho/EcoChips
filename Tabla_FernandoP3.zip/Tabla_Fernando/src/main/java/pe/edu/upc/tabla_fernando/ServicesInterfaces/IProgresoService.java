package pe.edu.upc.tabla_fernando.ServicesInterfaces;

import pe.edu.upc.tabla_fernando.Entities.Progreso;
import pe.edu.upc.tabla_fernando.DTOs.ResumenDTO;

import java.util.List;

public interface IProgresoService {
    List<Progreso> list();
    Progreso listId(int id);
    void insert(Progreso progreso);
    void update(Progreso progreso);
    void delete(int id);
    ResumenDTO obtenerResumen(int idUsuario);
}