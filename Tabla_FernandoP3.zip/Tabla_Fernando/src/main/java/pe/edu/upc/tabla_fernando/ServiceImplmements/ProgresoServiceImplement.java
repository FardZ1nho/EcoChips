package pe.edu.upc.tabla_fernando.ServiceImplmements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.tabla_fernando.Entities.Progreso;
import pe.edu.upc.tabla_fernando.Entities.Usuario;
import pe.edu.upc.tabla_fernando.Entities.Actividad;
import pe.edu.upc.tabla_fernando.Repositories.IProgresoRepository;
import pe.edu.upc.tabla_fernando.Repositories.IUsuarioRepository;
import pe.edu.upc.tabla_fernando.Repositories.IActividadRepository;
import pe.edu.upc.tabla_fernando.ServicesInterfaces.IProgresoService;
import pe.edu.upc.tabla_fernando.DTOs.ResumenDTO;

import java.time.LocalDate;
import java.util.List;

@Service
public class ProgresoServiceImplement implements IProgresoService {

    @Autowired
    private IProgresoRepository progresoRepo;

    @Autowired
    private IUsuarioRepository usuarioRepo;

    @Autowired
    private IActividadRepository actividadRepo;

    @Override
    public List<Progreso> list() {
        return progresoRepo.findAll();
    }

    @Override
    public Progreso listId(int id) {
        return progresoRepo.findById(id).orElse(null);
    }

    @Override
    public void insert(Progreso progreso) {
        Usuario usuario = usuarioRepo.findById(progreso.getUsuario().getIdUsuario())
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        Actividad actividad = actividadRepo.findById(progreso.getActividad().getIdActividad())
                .orElseThrow(() -> new IllegalArgumentException("Actividad no encontrada"));

        progreso.setUsuario(usuario);
        progreso.setActividad(actividad);

        usuario.setNivel(usuario.getNivel());
        int puntosGanados = progreso.getPuntos();

        int totalPuntos = puntosGanados;
        if (puntosGanados >= 100) {
            int nivelesExtra = puntosGanados / 100;
            usuario.setNivel(usuario.getNivel() + nivelesExtra);
        }

        usuarioRepo.save(usuario);

        progresoRepo.save(progreso);
    }

    @Override
    public void update(Progreso progreso) {
        progresoRepo.save(progreso);
    }

    @Override
    public void delete(int id) {
        progresoRepo.deleteById(id);
    }
    @Override
    public ResumenDTO obtenerResumen(int idUsuario) {
        Usuario usuario = usuarioRepo.findById(idUsuario).orElse(null);
        if (usuario == null) {
            return null;
        }

        int puntosTotales = progresoRepo.sumarPuntosPorUsuario(idUsuario);

        int nivel = (puntosTotales / 1000) + 1;
        usuario.setNivel(nivel);

        usuarioRepo.save(usuario);

        ResumenDTO dto = new ResumenDTO();
        dto.setNombre(usuario.getNombre());
        dto.setNivel(nivel);
        dto.setPuntos(puntosTotales);

        return dto;
    }
}