package pe.edu.upc.tabla_fernando.ServicesInterfaces;

import pe.edu.upc.tabla_fernando.Entities.Actividad;

import java.util.List;

public interface IActividadService {
    List<Actividad> list();
    Actividad listId(int id);
    void insert(Actividad actividad);
    void update(Actividad actividad);
    void delete(int id);
}
