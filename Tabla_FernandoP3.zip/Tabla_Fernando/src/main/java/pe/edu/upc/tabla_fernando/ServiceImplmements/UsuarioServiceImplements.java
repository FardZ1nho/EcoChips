package pe.edu.upc.tabla_fernando.ServiceImplmements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.tabla_fernando.Entities.Usuario;
import pe.edu.upc.tabla_fernando.Repositories.IUsuarioRepository;
import pe.edu.upc.tabla_fernando.ServicesInterfaces.IUsuarioService;

import java.util.List;

@Service
public class UsuarioServiceImplements implements IUsuarioService {
    @Autowired
    private IUsuarioRepository usuarioRepo;

    @Override
    public List<Usuario> list() {
        return usuarioRepo.findAll();
    }

    @Override
    public void insert(Usuario usuario) {
        usuarioRepo.save(usuario);
    }

    @Override
    public Usuario listId(int id) {
        return usuarioRepo.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        usuarioRepo.deleteById(id);
    }

    @Override
    public void update(Usuario usuario) {
        usuarioRepo.save(usuario);
    }

    @Override
    public List<Usuario> findByNivel(int nivel) {
        return usuarioRepo.findByNivel(nivel);
    }
}
