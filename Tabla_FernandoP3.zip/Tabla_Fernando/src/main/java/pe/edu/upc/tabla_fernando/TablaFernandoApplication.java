package pe.edu.upc.tabla_fernando;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TablaFernandoApplication {

    public static void main(String[] args) {
        SpringApplication.run(TablaFernandoApplication.class, args);
    }

}
