package com.github.fardz1nho.ecochips.entities;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "usuariorecomendacion")
public class UsuarioRecomendacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idUsuarioRecomendacion;

    @ManyToOne
    @JoinColumn(name = "idUsuario")
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "idRecomenda")
    private Recomendacion recomendacion;

    @Column(name = "fechaAsignacion", nullable = false)
    private LocalDate fechaAsignacion;

    public UsuarioRecomendacion() {}

    public UsuarioRecomendacion(int idUsuarioRecomendacion, Usuario usuario, Recomendacion recomendacion, LocalDate fechaAsignacion) {
        this.idUsuarioRecomendacion = idUsuarioRecomendacion;
        this.usuario = usuario;
        this.recomendacion = recomendacion;
        this.fechaAsignacion = fechaAsignacion;
    }

    public int getIdUsuarioRecomendacion() {
        return idUsuarioRecomendacion;
    }

    public void setIdUsuarioRecomendacion(int idUsuarioRecomendacion) {
        this.idUsuarioRecomendacion = idUsuarioRecomendacion;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Recomendacion getRecomendacion() {
        return recomendacion;
    }

    public void setRecomendacion(Recomendacion recomendacion) {
        this.recomendacion = recomendacion;
    }

    public LocalDate getFechaAsignacion() {
        return fechaAsignacion;
    }

    public void setFechaAsignacion(LocalDate fechaAsignacion) {
        this.fechaAsignacion = fechaAsignacion;
    }
}