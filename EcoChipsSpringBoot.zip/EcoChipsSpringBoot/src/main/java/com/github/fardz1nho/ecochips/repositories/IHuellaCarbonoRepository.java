package com.github.fardz1nho.ecochips.repositories;

import com.github.fardz1nho.ecochips.entities.HuellaCarbono;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface IHuellaCarbonoRepository extends JpaRepository<HuellaCarbono, Integer> {

    @Query("SELECT h FROM HuellaCarbono h WHERE h.usuario.idUsuario = :idUsuario")
    List<HuellaCarbono> findByUsuarioId(@Param("idUsuario") int idUsuario);

    @Query("SELECT h FROM HuellaCarbono h WHERE h.categoria = :categoria")
    List<HuellaCarbono> findByCategoria(@Param("categoria") String categoria);

    @Query("SELECT h FROM HuellaCarbono h WHERE h.usuario.idUsuario = :idUsuario AND h.fecha BETWEEN :fechaInicio AND :fechaFin")
    List<HuellaCarbono> findByUsuarioAndFechas(@Param("idUsuario") int idUsuario,
                                               @Param("fechaInicio") LocalDate fechaInicio,
                                               @Param("fechaFin") LocalDate fechaFin);

    @Query("SELECT h FROM HuellaCarbono h WHERE h.usuario.idUsuario = :idUsuario AND h.categoria = :categoria")
    List<HuellaCarbono> findByUsuarioAndCategoria(@Param("idUsuario") int idUsuario,
                                                  @Param("categoria") String categoria);

    @Query("SELECT h FROM HuellaCarbono h WHERE h.usuario.idUsuario = :idUsuario AND h.fecha BETWEEN :fechaInicio AND :fechaFin AND h.categoria = :categoria")
    List<HuellaCarbono> findByUsuarioFechasAndCategoria(@Param("idUsuario") int idUsuario,
                                                        @Param("fechaInicio") LocalDate fechaInicio,
                                                        @Param("fechaFin") LocalDate fechaFin,
                                                        @Param("categoria") String categoria);

    @Query("SELECT SUM(h.valorCO2) FROM HuellaCarbono h WHERE h.usuario.idUsuario = :idUsuario")
    Double getTotalCO2ByUsuario(@Param("idUsuario") int idUsuario);

    @Query("SELECT SUM(h.valorCO2) FROM HuellaCarbono h WHERE h.usuario.idUsuario = :idUsuario AND h.categoria = :categoria")
    Double getTotalCO2ByUsuarioAndCategoria(@Param("idUsuario") int idUsuario, @Param("categoria") String categoria);
}