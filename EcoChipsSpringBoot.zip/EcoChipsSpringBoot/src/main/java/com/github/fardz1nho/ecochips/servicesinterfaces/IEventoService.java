package com.github.fardz1nho.ecochips.servicesinterfaces;


import com.github.fardz1nho.ecochips.entities.Evento;

import java.util.List;


public interface IEventoService {

    public List<Evento> list();
    public Evento listId(int id);
    public void insert(Evento evento);
    void delete(int id);
}
