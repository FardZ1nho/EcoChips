package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.Evento;
import com.github.fardz1nho.ecochips.repositories.IEventoRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.IEventoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class EventoServiceImplement implements IEventoService
{
    @Autowired
    private IEventoRepository eS;

    @Override
    public List<Evento> list() {
        return eS.findAll();
    }

    @Override
    public Evento listId(int id) {
        return eS.findById(id).orElse(null);
    }

    @Override
    public void insert(Evento evento) {
        eS.save(evento);
    }

    @Override
    public void delete(int id) {
        eS.deleteById(id);
    }

}
