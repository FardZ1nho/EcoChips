package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.dtos.UsuarioRecompensaDTO;
import com.github.fardz1nho.ecochips.entities.UsuarioRecompensa;
import com.github.fardz1nho.ecochips.servicesinterfaces.IUsuarioRecompensaService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/canjes")
public class UsuarioRecompensaController {
    @Autowired
    private IUsuarioRecompensaService urS;

    @GetMapping("/dtos")
    public List<UsuarioRecompensaDTO> list(){
        return urS.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y,UsuarioRecompensaDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody UsuarioRecompensaDTO dto)
    {
        ModelMapper m = new ModelMapper();
        UsuarioRecompensa ur =m.map(dto, UsuarioRecompensa.class);
        urS.insert(ur);
    }
}
