package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.UsuarioRecompensa;
import com.github.fardz1nho.ecochips.repositories.IUsuarioRecompensaRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.IUsuarioRecompensaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioRecompensaServiceImplement implements IUsuarioRecompensaService {
    @Autowired
    private IUsuarioRecompensaRepository urS;

    @Override
    public List<UsuarioRecompensa> list() {return urS.findAll();}

    @Override
    public void insert(UsuarioRecompensa usuariorecompensa){urS.save(usuariorecompensa);}
}
