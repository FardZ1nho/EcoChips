package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.dtos.TipoRetoDTO;
import com.github.fardz1nho.ecochips.entities.TipoReto;
import com.github.fardz1nho.ecochips.servicesinterfaces.ITipoRetoService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/tiporeto")
public class TipoRetoController {
    @Autowired
    private ITipoRetoService tService;

    @PostMapping
    public void insertar(@RequestBody TipoRetoDTO dto){
        ModelMapper m = new ModelMapper();
        TipoReto t = m.map(dto, TipoReto.class);
        tService.insert(t);
    }

    @GetMapping
    public List<TipoRetoDTO> listar(){
        return tService.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, TipoRetoDTO.class);
        }).collect(Collectors.toList());
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id") Long id){
        tService.delete(id);
    }

    @GetMapping("/{id}")
    public TipoRetoDTO listarId(@PathVariable("id") Long id){
        ModelMapper m = new ModelMapper();
        return m.map(tService.listId(id), TipoRetoDTO.class);
    }
}
