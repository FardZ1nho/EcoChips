package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.Actividad;
import com.github.fardz1nho.ecochips.repositories.IActividadRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.IActividadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ActividadServiceImplement implements IActividadService {
    @Autowired
    private IActividadRepository aS;

    @Override
    public List<Actividad> list() {
        return aS.findAll();
    }

    @Override
    public Actividad listId(int id) {
        return aS.findById(id).orElse(null);
    }

    @Override
    public void insert(Actividad actividad) {
        aS.save(actividad);
    }
}
