package com.github.fardz1nho.ecochips.servicesinterfaces;

import com.github.fardz1nho.ecochips.entities.Rol;

import java.util.List;

public interface IRolService {
    List<Rol> list();

    void insert(Rol rol);

    Rol listId(int id);

    void delete(int id);

    void update(Rol rol);

    List<Rol> buscarR(String nombre);
}