package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.Progreso;
import com.github.fardz1nho.ecochips.repositories.IProgresoRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.IProgresoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProgresoServiceImplement implements IProgresoService {

    @Autowired
    private IProgresoRepository progresoRepository;

    @Override
    public List<Progreso> list() {
        return progresoRepository.findAll();
    }

    @Override
    public Progreso insert(Progreso progreso) {
        return progresoRepository.save(progreso);
    }

    @Override
    public Progreso update(Progreso progreso) {
        return progresoRepository.save(progreso);
    }

    @Override
    public void delete(int id) {
        progresoRepository.deleteById(id);
    }

    @Override
    public List<Progreso> findByUsuarioId(int idUsuario) {
        return progresoRepository.findByUsuarioId(idUsuario);
    }

    @Override
    public List<Progreso> findByEstado(String estado) {
        return progresoRepository.findByEstado(estado);
    }

    @Override
    public List<Progreso> findHistorialByUsuario(int idUsuario) {
        return progresoRepository.findHistorialByUsuario(idUsuario);
    }

    @Override
    public List<Progreso> findByUsuarioAndEstado(int idUsuario, String estado) {
        return progresoRepository.findByUsuarioAndEstado(idUsuario, estado);
    }

    @Override
    public Integer getTotalPuntosByUsuario(int idUsuario) {
        return progresoRepository.getTotalPuntosByUsuario(idUsuario);
    }
}