package com.github.fardz1nho.ecochips.controllers;


import com.github.fardz1nho.ecochips.dtos.ProgresoDTO;
import com.github.fardz1nho.ecochips.entities.Progreso;
import com.github.fardz1nho.ecochips.servicesinterfaces.IProgresoService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/progreso")
public class ProgresoController {

    @Autowired
    private IProgresoService progresoService;

    @GetMapping
    public List<ProgresoDTO> listar() {
        return progresoService.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, ProgresoDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody ProgresoDTO dto) {
        ModelMapper m = new ModelMapper();
        Progreso progreso = m.map(dto, Progreso.class);
        progresoService.insert(progreso);
    }

    @PutMapping
    public void modificar(@RequestBody ProgresoDTO dto) {
        ModelMapper m = new ModelMapper();
        Progreso progreso = m.map(dto, Progreso.class);
        progresoService.update(progreso);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id") Integer id) {
        progresoService.delete(id);
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<ProgresoDTO> listarPorUsuario(@PathVariable("idUsuario") int idUsuario) {
        return progresoService.findByUsuarioId(idUsuario).stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, ProgresoDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/estado/{estado}")
    public List<ProgresoDTO> listarPorEstado(@PathVariable("estado") String estado) {
        return progresoService.findByEstado(estado).stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, ProgresoDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/historial/{idUsuario}")
    public List<ProgresoDTO> obtenerHistorial(@PathVariable("idUsuario") int idUsuario) {
        return progresoService.findHistorialByUsuario(idUsuario).stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, ProgresoDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/usuario/{idUsuario}/estado/{estado}")
    public List<ProgresoDTO> listarPorUsuarioYEstado(@PathVariable("idUsuario") int idUsuario,
                                                     @PathVariable("estado") String estado) {
        return progresoService.findByUsuarioAndEstado(idUsuario, estado).stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, ProgresoDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/puntos/{idUsuario}")
    public Integer obtenerTotalPuntos(@PathVariable("idUsuario") int idUsuario) {
        return progresoService.getTotalPuntosByUsuario(idUsuario);
    }
}