package com.github.fardz1nho.ecochips.repositories;

import com.github.fardz1nho.ecochips.entities.Recomendacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IRecomendacionRepository extends JpaRepository<Recomendacion, Integer> {

    @Query("SELECT r FROM Recomendacion r WHERE r.tipo = :tipo")
    List<Recomendacion> findByTipo(@Param("tipo") String tipo);

    @Query("SELECT r FROM Recomendacion r WHERE r.titulo LIKE %:titulo%")
    List<Recomendacion> findByTituloContaining(@Param("titulo") String titulo);

    @Query("SELECT r FROM Recomendacion r WHERE r.descripcion LIKE %:descripcion%")
    List<Recomendacion> findByDescripcionContaining(@Param("descripcion") String descripcion);
}