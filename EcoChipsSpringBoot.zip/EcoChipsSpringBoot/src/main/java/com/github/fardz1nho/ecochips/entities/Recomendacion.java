package com.github.fardz1nho.ecochips.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "recomendacion")
public class Recomendacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idRecomenda;

    @Column(name = "titulo", length = 100, nullable = false)
    private String titulo;

    @Column(name = "descripcion", length = 255, nullable = false)
    private String descripcion;

    @Column(name = "tipo", length = 50, nullable = false)
    private String tipo;

    public Recomendacion() {}

    public Recomendacion(int idRecomenda, String titulo, String descripcion, String tipo) {
        this.idRecomenda = idRecomenda;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.tipo = tipo;
    }

    public int getIdRecomenda() {
        return idRecomenda;
    }

    public void setIdRecomenda(int idRecomenda) {
        this.idRecomenda = idRecomenda;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}