package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.SoporteRespuesta;
import com.github.fardz1nho.ecochips.repositories.ISoporteRespuestaRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.ISoporteRespuestaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SoporteRespuestaImplement implements ISoporteRespuestaService {
    @Autowired
    private ISoporteRespuestaRepository repository;

    @Override
    public List<SoporteRespuesta> listarRespuestas() {
        return repository.findAll();
    }

    @Override
    public SoporteRespuesta obtenerRespuestaPorId(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public SoporteRespuesta guardarRespuesta(SoporteRespuesta respuesta) {
        return repository.save(respuesta);
    }

    @Override
    public void eliminarRespuesta(int id) {
        repository.deleteById(id);
    }
}
