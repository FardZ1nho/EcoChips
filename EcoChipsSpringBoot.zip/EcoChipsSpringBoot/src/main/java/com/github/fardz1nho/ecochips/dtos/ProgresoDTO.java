package com.github.fardz1nho.ecochips.dtos;

import java.time.LocalDate;

public class ProgresoDTO {

    private int idProg;
    private int nivel;
    private int puntos;
    private LocalDate fecha;
    private String estado;
    private int idUsuario;
    private String nombreUsuario;

    public ProgresoDTO() {}

    public ProgresoDTO(int idProg, int nivel, int puntos, LocalDate fecha, String estado, int idUsuario, String nombreUsuario) {
        this.idProg = idProg;
        this.nivel = nivel;
        this.puntos = puntos;
        this.fecha = fecha;
        this.estado = estado;
        this.idUsuario = idUsuario;
        this.nombreUsuario = nombreUsuario;
    }

    public int getIdProg() {
        return idProg;
    }

    public void setIdProg(int idProg) {
        this.idProg = idProg;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }
}