package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.Recompensa;
import com.github.fardz1nho.ecochips.repositories.IRecompensaRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.IRecompensaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecompensaServiceImplement implements IRecompensaService {
    @Autowired
    private IRecompensaRepository rS;

    @Override
    public List<Recompensa> list(){ return rS.findAll(); }

    @Override
    public void insert(Recompensa recompensa){rS.save(recompensa);}

    @Override
    public Recompensa listId(int id){ return rS.findById(id).orElse(null); }

    @Override
    public List<Recompensa> listcostoPuntos(int costoPuntos) {
        return rS.findByCostoPuntos(costoPuntos);
    }

    @Override
    public List<Recompensa> buscarTitulo(String tituloRecompensa) {
        return rS.findByTituloRecompensa(tituloRecompensa);
    }
}
