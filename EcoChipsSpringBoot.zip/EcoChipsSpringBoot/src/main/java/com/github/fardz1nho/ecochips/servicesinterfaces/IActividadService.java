package com.github.fardz1nho.ecochips.servicesinterfaces;


import com.github.fardz1nho.ecochips.entities.Actividad;

import java.util.List;

public interface IActividadService {
    public List<Actividad> list();
    public Actividad listId(int id);
    public void insert(Actividad actividad);
}

