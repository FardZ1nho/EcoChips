package com.github.fardz1nho.ecochips.dtos;

import java.time.LocalDate;

public class UsuarioRecomendacionDTO {

    private int idUsuarioRecomendacion;
    private int idUsuario;
    private String nombreUsuario;
    private int idRecomenda;
    private String tituloRecomendacion;
    private String descripcionRecomendacion;
    private String tipoRecomendacion;
    private LocalDate fechaAsignacion;

    public UsuarioRecomendacionDTO() {}

    public UsuarioRecomendacionDTO(int idUsuarioRecomendacion, int idUsuario, String nombreUsuario,
                                   int idRecomenda, String tituloRecomendacion, String descripcionRecomendacion,
                                   String tipoRecomendacion, LocalDate fechaAsignacion) {
        this.idUsuarioRecomendacion = idUsuarioRecomendacion;
        this.idUsuario = idUsuario;
        this.nombreUsuario = nombreUsuario;
        this.idRecomenda = idRecomenda;
        this.tituloRecomendacion = tituloRecomendacion;
        this.descripcionRecomendacion = descripcionRecomendacion;
        this.tipoRecomendacion = tipoRecomendacion;
        this.fechaAsignacion = fechaAsignacion;
    }

    public int getIdUsuarioRecomendacion() {
        return idUsuarioRecomendacion;
    }

    public void setIdUsuarioRecomendacion(int idUsuarioRecomendacion) {
        this.idUsuarioRecomendacion = idUsuarioRecomendacion;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public int getIdRecomenda() {
        return idRecomenda;
    }

    public void setIdRecomenda(int idRecomenda) {
        this.idRecomenda = idRecomenda;
    }

    public String getTituloRecomendacion() {
        return tituloRecomendacion;
    }

    public void setTituloRecomendacion(String tituloRecomendacion) {
        this.tituloRecomendacion = tituloRecomendacion;
    }

    public String getDescripcionRecomendacion() {
        return descripcionRecomendacion;
    }

    public void setDescripcionRecomendacion(String descripcionRecomendacion) {
        this.descripcionRecomendacion = descripcionRecomendacion;
    }

    public String getTipoRecomendacion() {
        return tipoRecomendacion;
    }

    public void setTipoRecomendacion(String tipoRecomendacion) {
        this.tipoRecomendacion = tipoRecomendacion;
    }

    public LocalDate getFechaAsignacion() {
        return fechaAsignacion;
    }

    public void setFechaAsignacion(LocalDate fechaAsignacion) {
        this.fechaAsignacion = fechaAsignacion;
    }
}