package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.dtos.RecomendacionDTO;
import com.github.fardz1nho.ecochips.entities.Recomendacion;
import com.github.fardz1nho.ecochips.servicesinterfaces.IRecomendacionService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/recomendacion")
public class RecomendacionController {

    @Autowired
    private IRecomendacionService recomendacionService;

    @GetMapping
    public List<RecomendacionDTO> listar() {
        return recomendacionService.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, RecomendacionDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody RecomendacionDTO dto) {
        ModelMapper m = new ModelMapper();
        Recomendacion recomendacion = m.map(dto, Recomendacion.class);
        recomendacionService.insert(recomendacion);
    }

    @PutMapping
    public void modificar(@RequestBody RecomendacionDTO dto) {
        ModelMapper m = new ModelMapper();
        Recomendacion recomendacion = m.map(dto, Recomendacion.class);
        recomendacionService.update(recomendacion);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id") Integer id) {
        recomendacionService.delete(id);
    }

    @GetMapping("/tipo/{tipo}")
    public List<RecomendacionDTO> listarPorTipo(@PathVariable("tipo") String tipo) {
        return recomendacionService.findByTipo(tipo).stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, RecomendacionDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/buscar")
    public List<RecomendacionDTO> buscarPorTitulo(@RequestParam("titulo") String titulo) {
        return recomendacionService.findByTituloContaining(titulo).stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, RecomendacionDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/descripcion")
    public List<RecomendacionDTO> buscarPorDescripcion(@RequestParam("descripcion") String descripcion) {
        return recomendacionService.findByDescripcionContaining(descripcion).stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, RecomendacionDTO.class);
        }).collect(Collectors.toList());
    }
}