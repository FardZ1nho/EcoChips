package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.dtos.RolDTO;
import com.github.fardz1nho.ecochips.entities.Rol;
import org.modelmapper.ModelMapper;
import com.github.fardz1nho.ecochips.servicesinterfaces.IRolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/Roles")
public class RolController {
    @Autowired
    private IRolService rS;

    @GetMapping
    public List<RolDTO> listar(){
        return rS.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y, RolDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody RolDTO dto)
    {
        ModelMapper m = new ModelMapper();
        Rol r=m.map(dto,Rol.class);
        rS.insert(r);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable ("id") Integer id)
    {
        Rol rol = rS.listId(id);
        if(rol ==null)
        {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("El rol no existe" +id);
        }

        ModelMapper m = new ModelMapper();
        RolDTO dto = m.map(rol, RolDTO.class);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id)
    {
        Rol rol = rS.listId(id);
        if (rol == null)
        {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro con el ID" + id);
        }
        rS.delete(id);
        return ResponseEntity.ok("Registro con Id" +id+ "eliminado Correctamente");
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody RolDTO dto)
    {
        ModelMapper m = new ModelMapper();
        Rol r=m.map(dto,Rol.class);

        Rol existente = rS.listId(r.getIdRol());
        if (existente == null)
        {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe un registro con el ID" + r.getIdRol());
        }

        //Actualizar si pasa validaciones
        rS.update(r);
        return  ResponseEntity.ok("Registro con Id" +r.getIdRol()+"modificado correctamente");
    }

    @GetMapping("/buscar/{nombre}")
    public List<RolDTO> buscarPorNombre(@PathVariable("nombre") String nombre)
    {
        return rS.buscarR(nombre).stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y, RolDTO.class);
        }).collect(Collectors.toList());
    }
}