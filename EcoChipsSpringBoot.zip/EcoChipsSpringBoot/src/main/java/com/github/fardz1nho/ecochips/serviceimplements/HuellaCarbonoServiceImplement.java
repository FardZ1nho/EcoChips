package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.HuellaCarbono;
import com.github.fardz1nho.ecochips.repositories.IHuellaCarbonoRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.IHuellaCarbonoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class HuellaCarbonoServiceImplement implements IHuellaCarbonoService {

    @Autowired
    private IHuellaCarbonoRepository huellaCarbonoRepository;

    @Override
    public List<HuellaCarbono> list() {
        return huellaCarbonoRepository.findAll();
    }

    @Override
    public HuellaCarbono insert(HuellaCarbono huellaCarbono) {
        return huellaCarbonoRepository.save(huellaCarbono);
    }

    @Override
    public HuellaCarbono update(HuellaCarbono huellaCarbono) {
        return huellaCarbonoRepository.save(huellaCarbono);
    }

    @Override
    public void delete(int id) {
        huellaCarbonoRepository.deleteById(id);
    }

    @Override
    public List<HuellaCarbono> findByUsuarioId(int idUsuario) {
        return huellaCarbonoRepository.findByUsuarioId(idUsuario);
    }

    @Override
    public List<HuellaCarbono> findByCategoria(String categoria) {
        return huellaCarbonoRepository.findByCategoria(categoria);
    }

    @Override
    public List<HuellaCarbono> findByUsuarioAndFechas(int idUsuario, LocalDate fechaInicio, LocalDate fechaFin) {
        return huellaCarbonoRepository.findByUsuarioAndFechas(idUsuario, fechaInicio, fechaFin);
    }

    @Override
    public List<HuellaCarbono> findByUsuarioAndCategoria(int idUsuario, String categoria) {
        return huellaCarbonoRepository.findByUsuarioAndCategoria(idUsuario, categoria);
    }

    @Override
    public List<HuellaCarbono> findByUsuarioFechasAndCategoria(int idUsuario, LocalDate fechaInicio, LocalDate fechaFin, String categoria) {
        return huellaCarbonoRepository.findByUsuarioFechasAndCategoria(idUsuario, fechaInicio, fechaFin, categoria);
    }

    @Override
    public Double getTotalCO2ByUsuario(int idUsuario) {
        return huellaCarbonoRepository.getTotalCO2ByUsuario(idUsuario);
    }

    @Override
    public Double getTotalCO2ByUsuarioAndCategoria(int idUsuario, String categoria) {
        return huellaCarbonoRepository.getTotalCO2ByUsuarioAndCategoria(idUsuario, categoria);
    }
}