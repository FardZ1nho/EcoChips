package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.dtos.UsuarioHabitoDTO;
import com.github.fardz1nho.ecochips.entities.UsuarioHabito;
import com.github.fardz1nho.ecochips.servicesinterfaces.IUsuarioHabitoService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/progreso-habitos")
public class UsuarioHabitoController {
    @Autowired
    private IUsuarioHabitoService uhS;

    @PostMapping
    public void insert(@RequestBody UsuarioHabitoDTO dto)
    {
        ModelMapper m = new ModelMapper();
        UsuarioHabito uh =m.map(dto, UsuarioHabito.class);
        uhS.insert(uh);
    }

    @GetMapping("/dtos")
    public List<UsuarioHabitoDTO> list(){
        return uhS.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y,UsuarioHabitoDTO.class);
        }).collect(Collectors.toList());
    }
}
