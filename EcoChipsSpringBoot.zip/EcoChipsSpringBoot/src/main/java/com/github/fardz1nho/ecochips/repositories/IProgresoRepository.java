package com.github.fardz1nho.ecochips.repositories;

import com.github.fardz1nho.ecochips.entities.Progreso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IProgresoRepository extends JpaRepository<Progreso, Integer> {

    @Query("SELECT p FROM Progreso p WHERE p.usuario.idUsuario = :idUsuario")
    List<Progreso> findByUsuarioId(@Param("idUsuario") int idUsuario);

    @Query("SELECT p FROM Progreso p WHERE p.estado = :estado")
    List<Progreso> findByEstado(@Param("estado") String estado);

    @Query("SELECT p FROM Progreso p WHERE p.usuario.idUsuario = :idUsuario ORDER BY p.fecha DESC")
    List<Progreso> findHistorialByUsuario(@Param("idUsuario") int idUsuario);

    @Query("SELECT p FROM Progreso p WHERE p.usuario.idUsuario = :idUsuario AND p.estado = :estado")
    List<Progreso> findByUsuarioAndEstado(@Param("idUsuario") int idUsuario, @Param("estado") String estado);

    @Query("SELECT SUM(p.puntos) FROM Progreso p WHERE p.usuario.idUsuario = :idUsuario")
    Integer getTotalPuntosByUsuario(@Param("idUsuario") int idUsuario);
}