package com.github.fardz1nho.ecochips.servicesinterfaces;

import com.github.fardz1nho.ecochips.entities.SoporteSolicitud;

import java.util.List;

public interface ISoporteSolicitudService {
    public List<SoporteSolicitud> list();
    public void insert(SoporteSolicitud solicitud);
    public SoporteSolicitud listID(int id);
    public void update(SoporteSolicitud solicitud);
    public void delete(int id);
    public List<SoporteSolicitud> buscarSoporteSolicitud(String titulo);
}
