package com.github.fardz1nho.ecochips.dtos;



import com.github.fardz1nho.ecochips.entities.Actividad;
import com.github.fardz1nho.ecochips.entities.Evento;
import com.github.fardz1nho.ecochips.entities.Reto;
import com.github.fardz1nho.ecochips.entities.Usuario;

import java.time.LocalDateTime;

public class NotificacionDTO {

    private int idNotificacion;
    private Usuario usuario;
    private Actividad actividad;
    private Reto reto;
    private Evento evento;
    private String tipo;
    private String titulo;
    private String mensaje;
    private LocalDateTime fechaCrea;

    public int getIdNotificacion() {
        return idNotificacion;
    }

    public void setIdNotificacion(int idNotificacion) {
        this.idNotificacion = idNotificacion;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Actividad getActividad() {
        return actividad;
    }

    public void setActividad(Actividad actividad) {
        this.actividad = actividad;
    }

    public Reto getReto() {
        return reto;
    }

    public void setReto(Reto reto) {
        this.reto = reto;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public LocalDateTime getFechaCrea() {
        return fechaCrea;
    }

    public void setFechaCrea(LocalDateTime fechaCrea) {
        this.fechaCrea = fechaCrea;
    }
}
