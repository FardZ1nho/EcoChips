package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.UsuarioHabito;
import com.github.fardz1nho.ecochips.repositories.IUsuarioHabitoRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.IUsuarioHabitoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioHabitoServiceImplement implements IUsuarioHabitoService {
    @Autowired
    private IUsuarioHabitoRepository uhS;

    @Override
    public List<UsuarioHabito> list() {return uhS.findAll();}

    @Override
    public void insert(UsuarioHabito usuariohabito) {uhS.save(usuariohabito);}
}
