package com.github.fardz1nho.ecochips.repositories;

import com.github.fardz1nho.ecochips.entities.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository

public interface INotificacionRepository extends JpaRepository<Notificacion, Integer> {
}
