package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.UsuarioEvento;
import com.github.fardz1nho.ecochips.repositories.IUsuarioEventoRepositoy;
import com.github.fardz1nho.ecochips.servicesinterfaces.IUsuarioEventoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service


public class UsuarioEventoImplement implements IUsuarioEventoService {

    @Autowired
    private IUsuarioEventoRepositoy ueS;

    @Override
    public List<UsuarioEvento> list() {return ueS.findAll();}

    @Override
    public void insert(UsuarioEvento usuarioEvento) {ueS.save(usuarioEvento);}
}
