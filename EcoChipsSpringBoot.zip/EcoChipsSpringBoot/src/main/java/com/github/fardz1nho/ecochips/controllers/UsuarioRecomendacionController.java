package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.dtos.UsuarioRecomendacionDTO;
import com.github.fardz1nho.ecochips.entities.UsuarioRecomendacion;
import com.github.fardz1nho.ecochips.servicesinterfaces.IUsuarioRecomendacionService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/usuariorecomendacion")
public class UsuarioRecomendacionController {

    @Autowired
    private IUsuarioRecomendacionService usuarioRecomendacionService;

    @GetMapping
    public List<UsuarioRecomendacionDTO> listar() {
        return usuarioRecomendacionService.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, UsuarioRecomendacionDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void asignar(@RequestBody UsuarioRecomendacionDTO dto) {
        ModelMapper m = new ModelMapper();
        UsuarioRecomendacion usuarioRecomendacion = m.map(dto, UsuarioRecomendacion.class);
        usuarioRecomendacionService.insert(usuarioRecomendacion);
    }

    @PutMapping
    public void modificar(@RequestBody UsuarioRecomendacionDTO dto) {
        ModelMapper m = new ModelMapper();
        UsuarioRecomendacion usuarioRecomendacion = m.map(dto, UsuarioRecomendacion.class);
        usuarioRecomendacionService.update(usuarioRecomendacion);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id") Integer id) {
        usuarioRecomendacionService.delete(id);
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<UsuarioRecomendacionDTO> listarPorUsuario(@PathVariable("idUsuario") int idUsuario) {
        return usuarioRecomendacionService.findByUsuarioId(idUsuario).stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, UsuarioRecomendacionDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/usuario/{idUsuario}/tipo/{tipo}")
    public List<UsuarioRecomendacionDTO> filtrarPorTipo(@PathVariable("idUsuario") int idUsuario,
                                                        @PathVariable("tipo") String tipo) {
        return usuarioRecomendacionService.findByUsuarioAndTipo(idUsuario, tipo).stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, UsuarioRecomendacionDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/recomendacion/{idRecomenda}")
    public List<UsuarioRecomendacionDTO> listarPorRecomendacion(@PathVariable("idRecomenda") int idRecomenda) {
        return usuarioRecomendacionService.findByRecomendacionId(idRecomenda).stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, UsuarioRecomendacionDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/verificar/{idUsuario}/{idRecomenda}")
    public UsuarioRecomendacionDTO verificarAsignacion(@PathVariable("idUsuario") int idUsuario,
                                                       @PathVariable("idRecomenda") int idRecomenda) {
        UsuarioRecomendacion usuarioRecomendacion = usuarioRecomendacionService.findByUsuarioAndRecomendacion(idUsuario, idRecomenda);
        if (usuarioRecomendacion != null) {
            ModelMapper m = new ModelMapper();
            return m.map(usuarioRecomendacion, UsuarioRecomendacionDTO.class);
        }
        return null;
    }

    @GetMapping("/contar/usuario/{idUsuario}")
    public Integer contarPorUsuario(@PathVariable("idUsuario") int idUsuario) {
        return usuarioRecomendacionService.countRecomendacionesByUsuario(idUsuario);
    }

    @GetMapping("/contar/tipo/{tipo}")
    public Integer contarPorTipo(@PathVariable("tipo") String tipo) {
        return usuarioRecomendacionService.countByTipo(tipo);
    }

    @PostMapping("/asignar/{idUsuario}/{idRecomenda}")
    public void asignarRecomendacion(@PathVariable("idUsuario") int idUsuario,
                                     @PathVariable("idRecomenda") int idRecomenda) {
        UsuarioRecomendacionDTO dto = new UsuarioRecomendacionDTO();
        dto.setIdUsuario(idUsuario);
        dto.setIdRecomenda(idRecomenda);
        dto.setFechaAsignacion(java.time.LocalDate.now());

        ModelMapper m = new ModelMapper();
        UsuarioRecomendacion usuarioRecomendacion = m.map(dto, UsuarioRecomendacion.class);
        usuarioRecomendacionService.insert(usuarioRecomendacion);
    }

    @DeleteMapping("/completar/{idUsuario}/{idRecomenda}")
    public void marcarCompletada(@PathVariable("idUsuario") int idUsuario,
                                 @PathVariable("idRecomenda") int idRecomenda) {
        UsuarioRecomendacion usuarioRecomendacion = usuarioRecomendacionService.findByUsuarioAndRecomendacion(idUsuario, idRecomenda);
        if (usuarioRecomendacion != null) {
            usuarioRecomendacionService.delete(usuarioRecomendacion.getIdUsuarioRecomendacion());
        }
    }
}
