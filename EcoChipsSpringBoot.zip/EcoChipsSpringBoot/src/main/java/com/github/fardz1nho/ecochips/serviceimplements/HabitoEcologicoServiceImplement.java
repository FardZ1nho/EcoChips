package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.HabitoEcologico;
import com.github.fardz1nho.ecochips.repositories.IHabitoEcologicoRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.IHabitoEcologicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class HabitoEcologicoServiceImplement implements IHabitoEcologicoService {
    @Autowired
    private IHabitoEcologicoRepository hS;

    @Override
    public List<HabitoEcologico> list() {return hS.findAll();}

    @Override
    public HabitoEcologico listId(int id) {return hS.findById(id).orElse(null);}

    @Override
    public void insert(HabitoEcologico habitoecologico) {hS.save(habitoecologico);}

    @Override
    public void delete(int id) {hS.deleteById(id);}

    @Override
    public void update(HabitoEcologico habitoecologico) {hS.save(habitoecologico);}

    @Override
    public List<HabitoEcologico> buscar(String tituloHabito) {return hS.buscar(tituloHabito);}
}
