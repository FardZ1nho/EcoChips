package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.dtos.ParticipacionRetoDTO;
import com.github.fardz1nho.ecochips.entities.ParticipacionReto;
import com.github.fardz1nho.ecochips.servicesinterfaces.IParticipacionRetoService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/participaciones")
public class ParticipacionRetoController {
    @Autowired
    private IParticipacionRetoService prService;

    @GetMapping
    public List<ParticipacionRetoDTO> listar() {
        ModelMapper m = new ModelMapper();
        return prService.list().stream().map(x -> m.map(x,
                        ParticipacionRetoDTO.class))
                .collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody ParticipacionRetoDTO dto) {
        ModelMapper m = new ModelMapper();
        ParticipacionReto p = m.map(dto, ParticipacionReto.class);
        prService.insert(p);
    }
}
