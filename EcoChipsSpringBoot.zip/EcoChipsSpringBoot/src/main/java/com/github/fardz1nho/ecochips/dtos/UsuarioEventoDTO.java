package com.github.fardz1nho.ecochips.dtos;



import com.github.fardz1nho.ecochips.entities.Evento;
import com.github.fardz1nho.ecochips.entities.Usuario;

import java.time.LocalDate;


public class UsuarioEventoDTO {

    private int idUsuarioEvento;
    private Usuario usuario;
    private Evento evento;
    private LocalDate fechaRegistro;

    public int getIdUsuarioEvento() {
        return idUsuarioEvento;
    }

    public void setIdUsuarioEvento(int idUsuarioEvento) {
        this.idUsuarioEvento = idUsuarioEvento;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
}
