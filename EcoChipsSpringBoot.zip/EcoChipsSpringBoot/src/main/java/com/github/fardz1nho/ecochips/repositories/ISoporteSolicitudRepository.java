package com.github.fardz1nho.ecochips.repositories;

import com.github.fardz1nho.ecochips.entities.SoporteSolicitud;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ISoporteSolicitudRepository extends JpaRepository<SoporteSolicitud, Integer> {


}
