package com.github.fardz1nho.ecochips.entities;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "progreso")
public class Progreso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idProg;

    @Column(name = "nivel", nullable = false)
    private int nivel;

    @Column(name = "puntos", nullable = false)
    private int puntos;

    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    @Column(name = "estado", length = 20, nullable = false)
    private String estado;

    @ManyToOne
    @JoinColumn(name = "idUsuario")
    private Usuario usuario;

    public Progreso() {}

    public Progreso(int idProg, int nivel, int puntos, LocalDate fecha, String estado, Usuario usuario) {
        this.idProg = idProg;
        this.nivel = nivel;
        this.puntos = puntos;
        this.fecha = fecha;
        this.estado = estado;
        this.usuario = usuario;
    }

    public int getIdProg() {
        return idProg;
    }

    public void setIdProg(int idProg) {
        this.idProg = idProg;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}