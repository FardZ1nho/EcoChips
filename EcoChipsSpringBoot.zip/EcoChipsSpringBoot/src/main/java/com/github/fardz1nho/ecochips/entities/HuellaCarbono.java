package com.github.fardz1nho.ecochips.entities;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "huellacarbono")
public class HuellaCarbono {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idHuella;

    @Column(name = "valorCO2", nullable = false)
    private double valorCO2;

    @Column(name = "categoria", length = 50, nullable = false)
    private String categoria;

    @Column(name = "fuente", length = 100, nullable = false)
    private String fuente;

    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    @ManyToOne
    @JoinColumn(name = "idUsuario")
    private Usuario usuario;

    public HuellaCarbono() {}

    public HuellaCarbono(int idHuella, double valorCO2, String categoria, String fuente, LocalDate fecha, Usuario usuario) {
        this.idHuella = idHuella;
        this.valorCO2 = valorCO2;
        this.categoria = categoria;
        this.fuente = fuente;
        this.fecha = fecha;
        this.usuario = usuario;
    }

    public int getIdHuella() {
        return idHuella;
    }

    public void setIdHuella(int idHuella) {
        this.idHuella = idHuella;
    }

    public double getValorCO2() {
        return valorCO2;
    }

    public void setValorCO2(double valorCO2) {
        this.valorCO2 = valorCO2;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getFuente() {
        return fuente;
    }

    public void setFuente(String fuente) {
        this.fuente = fuente;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}
