package com.github.fardz1nho.ecochips.dtos;

public class RecomendacionDTO {

    private int idRecomenda;
    private String titulo;
    private String descripcion;
    private String tipo;

    public RecomendacionDTO() {}

    public RecomendacionDTO(int idRecomenda, String titulo, String descripcion, String tipo) {
        this.idRecomenda = idRecomenda;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.tipo = tipo;
    }

    public int getIdRecomenda() {
        return idRecomenda;
    }

    public void setIdRecomenda(int idRecomenda) {
        this.idRecomenda = idRecomenda;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}