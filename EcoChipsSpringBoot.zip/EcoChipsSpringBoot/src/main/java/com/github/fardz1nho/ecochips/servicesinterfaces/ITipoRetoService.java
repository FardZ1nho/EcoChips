package com.github.fardz1nho.ecochips.servicesinterfaces;


import com.github.fardz1nho.ecochips.entities.TipoReto;

import java.util.List;

public interface ITipoRetoService {
    void insert(TipoReto tipoReto);
    List<TipoReto> list();
    void delete(Long idTipoReto);
    TipoReto listId(Long idTipoReto);
}
