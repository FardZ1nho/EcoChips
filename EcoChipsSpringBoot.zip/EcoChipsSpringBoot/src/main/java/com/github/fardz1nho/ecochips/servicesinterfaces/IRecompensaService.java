package com.github.fardz1nho.ecochips.servicesinterfaces;



import com.github.fardz1nho.ecochips.entities.Recompensa;

import java.util.List;

public interface IRecompensaService {
    public List<Recompensa> list();
    public void insert(Recompensa recompensa);
    public Recompensa listId(int id);
    public List<Recompensa> listcostoPuntos(int costoPuntos);
    public List<Recompensa> buscarTitulo(String tituloRecompensa);
}
