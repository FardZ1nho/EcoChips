package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.dtos.ActividadDTO;
import com.github.fardz1nho.ecochips.entities.Actividad;
import com.github.fardz1nho.ecochips.servicesinterfaces.IActividadService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/actividades")
public class ActividadController {
    @Autowired
    private IActividadService aS;
    @GetMapping
    public List<ActividadDTO> list(){
        return aS.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y,ActividadDTO.class);
        }).collect(Collectors.toList());
    }
    @PostMapping
    public void insertar(@RequestBody ActividadDTO dto)
    {
        ModelMapper m = new ModelMapper();
        Actividad a=m.map(dto,Actividad.class);
        aS.insert(a);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Actividad dev = aS.listId(id);
        if (dev == null) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("No existe una actividad con el ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        ActividadDTO dto = m.map(dev, ActividadDTO.class);
        return ResponseEntity.ok(dto);
    }


}
