package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.UsuarioRecomendacion;
import com.github.fardz1nho.ecochips.repositories.IUsuarioRecomendacionRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.IUsuarioRecomendacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioRecomendacionServiceImplement implements IUsuarioRecomendacionService {

    @Autowired
    private IUsuarioRecomendacionRepository usuarioRecomendacionRepository;

    @Override
    public List<UsuarioRecomendacion> list() {
        return usuarioRecomendacionRepository.findAll();
    }

    @Override
    public UsuarioRecomendacion insert(UsuarioRecomendacion usuarioRecomendacion) {
        return usuarioRecomendacionRepository.save(usuarioRecomendacion);
    }

    @Override
    public UsuarioRecomendacion update(UsuarioRecomendacion usuarioRecomendacion) {
        return usuarioRecomendacionRepository.save(usuarioRecomendacion);
    }

    @Override
    public void delete(int id) {
        usuarioRecomendacionRepository.deleteById(id);
    }

    @Override
    public List<UsuarioRecomendacion> findByUsuarioId(int idUsuario) {
        return usuarioRecomendacionRepository.findByUsuarioId(idUsuario);
    }

    @Override
    public List<UsuarioRecomendacion> findByRecomendacionId(int idRecomenda) {
        return usuarioRecomendacionRepository.findByRecomendacionId(idRecomenda);
    }

    @Override
    public List<UsuarioRecomendacion> findByUsuarioAndTipo(int idUsuario, String tipo) {
        return usuarioRecomendacionRepository.findByUsuarioAndTipo(idUsuario, tipo);
    }

    @Override
    public UsuarioRecomendacion findByUsuarioAndRecomendacion(int idUsuario, int idRecomenda) {
        return usuarioRecomendacionRepository.findByUsuarioAndRecomendacion(idUsuario, idRecomenda);
    }

    @Override
    public Integer countRecomendacionesByUsuario(int idUsuario) {
        return usuarioRecomendacionRepository.countRecomendacionesByUsuario(idUsuario);
    }

    @Override
    public Integer countByTipo(String tipo) {
        return usuarioRecomendacionRepository.countByTipo(tipo);
    }
}