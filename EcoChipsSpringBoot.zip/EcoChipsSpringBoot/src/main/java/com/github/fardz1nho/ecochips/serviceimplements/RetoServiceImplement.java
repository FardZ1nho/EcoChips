package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.Reto;
import com.github.fardz1nho.ecochips.repositories.IRetoRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.IRetoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class RetoServiceImplement implements IRetoService {
    @Autowired
    private IRetoRepository rRepo;

    @Override
    public void insert(Reto reto){
        rRepo.save(reto);
    }

    @Override
    public List<Reto> list(){
        return rRepo.findAll();
    }

    @Override
    public void delete(Long idReto){
        rRepo.deleteById(idReto);
    }

    @Override
    public Reto listId(Long idReto){
        return rRepo.findById(idReto).orElse(new Reto());
    }
}
