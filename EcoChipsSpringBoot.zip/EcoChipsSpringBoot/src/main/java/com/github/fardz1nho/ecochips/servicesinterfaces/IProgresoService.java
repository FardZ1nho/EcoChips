package com.github.fardz1nho.ecochips.servicesinterfaces;

import com.github.fardz1nho.ecochips.entities.Progreso;

import java.util.List;

public interface IProgresoService {

    List<Progreso> list();

    Progreso insert(Progreso progreso);

    Progreso update(Progreso progreso);

    void delete(int id);

    List<Progreso> findByUsuarioId(int idUsuario);

    List<Progreso> findByEstado(String estado);

    List<Progreso> findHistorialByUsuario(int idUsuario);

    List<Progreso> findByUsuarioAndEstado(int idUsuario, String estado);

    Integer getTotalPuntosByUsuario(int idUsuario);
}