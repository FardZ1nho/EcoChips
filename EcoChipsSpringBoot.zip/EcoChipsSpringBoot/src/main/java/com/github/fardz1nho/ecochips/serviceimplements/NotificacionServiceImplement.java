package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.Notificacion;
import com.github.fardz1nho.ecochips.repositories.INotificacionRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.INotificacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class NotificacionServiceImplement implements INotificacionService {

    @Autowired
    private INotificacionRepository nS;

    @Override
    public List<Notificacion> list() {
        return nS.findAll();
    }

    @Override
    public Notificacion listId(int id) {
        return nS.findById(id).orElse(null);
    }

    @Override
    public void insert(Notificacion notificacion) {
        nS.save(notificacion);
    }
}
