package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.dtos.SoporteSolicitudDTO;
import com.github.fardz1nho.ecochips.entities.SoporteSolicitud;
import com.github.fardz1nho.ecochips.servicesinterfaces.ISoporteSolicitudService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/soporte")
public class SoporteSolicitudController {
    @Autowired
    private ISoporteSolicitudService sR;

    @GetMapping
    public List<SoporteSolicitudDTO> listar() {
        return sR.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y,SoporteSolicitudDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody SoporteSolicitudDTO solicitud) {
        ModelMapper m = new ModelMapper();
        SoporteSolicitud so = m.map(solicitud, SoporteSolicitud.class);
        sR.insert(so);
    }




}
