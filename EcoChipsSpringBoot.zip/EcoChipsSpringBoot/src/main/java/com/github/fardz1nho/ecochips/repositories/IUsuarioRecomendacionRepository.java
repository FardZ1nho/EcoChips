package com.github.fardz1nho.ecochips.repositories;

import com.github.fardz1nho.ecochips.entities.UsuarioRecomendacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IUsuarioRecomendacionRepository extends JpaRepository<UsuarioRecomendacion, Integer> {

    @Query("SELECT ur FROM UsuarioRecomendacion ur WHERE ur.usuario.idUsuario = :idUsuario")
    List<UsuarioRecomendacion> findByUsuarioId(@Param("idUsuario") int idUsuario);

    @Query("SELECT ur FROM UsuarioRecomendacion ur WHERE ur.recomendacion.idRecomenda = :idRecomenda")
    List<UsuarioRecomendacion> findByRecomendacionId(@Param("idRecomenda") int idRecomenda);

    @Query("SELECT ur FROM UsuarioRecomendacion ur WHERE ur.usuario.idUsuario = :idUsuario AND ur.recomendacion.tipo = :tipo")
    List<UsuarioRecomendacion> findByUsuarioAndTipo(@Param("idUsuario") int idUsuario, @Param("tipo") String tipo);

    @Query("SELECT ur FROM UsuarioRecomendacion ur WHERE ur.usuario.idUsuario = :idUsuario AND ur.recomendacion.idRecomenda = :idRecomenda")
    UsuarioRecomendacion findByUsuarioAndRecomendacion(@Param("idUsuario") int idUsuario, @Param("idRecomenda") int idRecomenda);

    @Query("SELECT COUNT(ur) FROM UsuarioRecomendacion ur WHERE ur.usuario.idUsuario = :idUsuario")
    Integer countRecomendacionesByUsuario(@Param("idUsuario") int idUsuario);

    @Query("SELECT COUNT(ur) FROM UsuarioRecomendacion ur WHERE ur.recomendacion.tipo = :tipo")
    Integer countByTipo(@Param("tipo") String tipo);
}