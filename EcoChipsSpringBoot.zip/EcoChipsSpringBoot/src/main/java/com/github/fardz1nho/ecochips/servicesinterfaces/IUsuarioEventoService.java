package com.github.fardz1nho.ecochips.servicesinterfaces;


import com.github.fardz1nho.ecochips.entities.UsuarioEvento;

import java.util.List;

public interface IUsuarioEventoService {

    public List<UsuarioEvento> list();
    public void insert(UsuarioEvento usuarioEvento);
}
