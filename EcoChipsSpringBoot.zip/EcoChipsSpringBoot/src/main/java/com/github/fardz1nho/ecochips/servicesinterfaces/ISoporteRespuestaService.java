package com.github.fardz1nho.ecochips.servicesinterfaces;

import com.github.fardz1nho.ecochips.entities.SoporteRespuesta;

import java.util.List;

public interface ISoporteRespuestaService {
    List<SoporteRespuesta> listarRespuestas();
    SoporteRespuesta obtenerRespuestaPorId(int id);
    SoporteRespuesta guardarRespuesta(SoporteRespuesta respuesta);
    void eliminarRespuesta(int id);
}
