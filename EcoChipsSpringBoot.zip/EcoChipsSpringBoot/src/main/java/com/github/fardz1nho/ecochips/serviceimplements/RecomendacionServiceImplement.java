package com.github.fardz1nho.ecochips.serviceimplements;

import com.github.fardz1nho.ecochips.entities.Recomendacion;
import com.github.fardz1nho.ecochips.repositories.IRecomendacionRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.IRecomendacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecomendacionServiceImplement implements IRecomendacionService {

    @Autowired
    private IRecomendacionRepository recomendacionRepository;

    @Override
    public List<Recomendacion> list() {
        return recomendacionRepository.findAll();
    }

    @Override
    public Recomendacion insert(Recomendacion recomendacion) {
        return recomendacionRepository.save(recomendacion);
    }

    @Override
    public Recomendacion update(Recomendacion recomendacion) {
        return recomendacionRepository.save(recomendacion);
    }

    @Override
    public void delete(int id) {
        recomendacionRepository.deleteById(id);
    }

    @Override
    public List<Recomendacion> findByTipo(String tipo) {
        return recomendacionRepository.findByTipo(tipo);
    }

    @Override
    public List<Recomendacion> findByTituloContaining(String titulo) {
        return recomendacionRepository.findByTituloContaining(titulo);
    }

    @Override
    public List<Recomendacion> findByDescripcionContaining(String descripcion) {
        return recomendacionRepository.findByDescripcionContaining(descripcion);
    }
}