package com.github.fardz1nho.ecochips.dtos;

import java.time.LocalDate;

public class HuellaCarbonoDTO {

    private int idHuella;
    private double valorCO2;
    private String categoria;
    private String fuente;
    private LocalDate fecha;
    private int idUsuario;
    private String nombreUsuario;

    public HuellaCarbonoDTO() {}

    public HuellaCarbonoDTO(int idHuella, double valorCO2, String categoria, String fuente, LocalDate fecha, int idUsuario, String nombreUsuario) {
        this.idHuella = idHuella;
        this.valorCO2 = valorCO2;
        this.categoria = categoria;
        this.fuente = fuente;
        this.fecha = fecha;
        this.idUsuario = idUsuario;
        this.nombreUsuario = nombreUsuario;
    }

    public int getIdHuella() {
        return idHuella;
    }

    public void setIdHuella(int idHuella) {
        this.idHuella = idHuella;
    }

    public double getValorCO2() {
        return valorCO2;
    }

    public void setValorCO2(double valorCO2) {
        this.valorCO2 = valorCO2;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getFuente() {
        return fuente;
    }

    public void setFuente(String fuente) {
        this.fuente = fuente;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }
}