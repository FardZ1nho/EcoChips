package com.github.fardz1nho.ecochips.dtos;



import com.github.fardz1nho.ecochips.entities.Reto;
import com.github.fardz1nho.ecochips.entities.Usuario;

import java.time.LocalDate;

public class ParticipacionRetoDTO {
    private int idParticipacion;
    private Usuario usuario;
    private Reto reto;
    private LocalDate fechaRegistro;
    private String estado;
    private int puntosObtenidos;

    public int getIdParticipacion() {
        return idParticipacion;
    }

    public void setIdParticipacion(int idParticipacion) {
        this.idParticipacion = idParticipacion;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Reto getReto() {
        return reto;
    }

    public void setReto(Reto reto) {
        this.reto = reto;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getPuntosObtenidos() {
        return puntosObtenidos;
    }

    public void setPuntosObtenidos(int puntosObtenidos) {
        this.puntosObtenidos = puntosObtenidos;
    }
}
