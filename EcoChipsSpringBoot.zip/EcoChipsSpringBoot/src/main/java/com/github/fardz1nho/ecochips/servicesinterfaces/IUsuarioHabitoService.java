package com.github.fardz1nho.ecochips.servicesinterfaces;


import com.github.fardz1nho.ecochips.entities.UsuarioHabito;

import java.util.List;

public interface IUsuarioHabitoService {
    public List<UsuarioHabito> list();
    public void insert(UsuarioHabito usuariohabito);
}
