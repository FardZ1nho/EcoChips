package com.github.fardz1nho.ecochips.servicesinterfaces;


import com.github.fardz1nho.ecochips.entities.Notificacion;

import java.util.List;

public interface INotificacionService {

    public List<Notificacion> list();
    public Notificacion listId(int id);
    public void insert(Notificacion notificacion);
}
