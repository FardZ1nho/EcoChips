package com.github.fardz1nho.ecochips.serviceimplements;


import com.github.fardz1nho.ecochips.entities.SoporteSolicitud;
import com.github.fardz1nho.ecochips.repositories.ISoporteSolicitudRepository;
import com.github.fardz1nho.ecochips.servicesinterfaces.ISoporteSolicitudService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SoporteSolicitudImplement implements ISoporteSolicitudService {
    @Autowired
    private ISoporteSolicitudRepository sR;

    @Override
    public List<SoporteSolicitud> list() {
        return sR.findAll();
    }

    @Override
    public void insert(SoporteSolicitud solicitud) {
        sR.save(solicitud);

    }

    @Override
    public SoporteSolicitud listID(int id) {
       return sR.findById(id).orElse(null);
    }

    @Override
    public void update(SoporteSolicitud solicitud) {
        sR.save(solicitud);
    }

    @Override
    public void delete(int id) {
        sR.deleteById(id);
    }

    @Override
    public List<SoporteSolicitud> buscarSoporteSolicitud(String titulo) {
       return  null;
    }
}
