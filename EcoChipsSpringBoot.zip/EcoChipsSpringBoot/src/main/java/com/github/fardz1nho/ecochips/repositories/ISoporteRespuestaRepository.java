package com.github.fardz1nho.ecochips.repositories;

import com.github.fardz1nho.ecochips.entities.SoporteRespuesta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ISoporteRespuestaRepository extends JpaRepository<SoporteRespuesta, Integer> {
}
