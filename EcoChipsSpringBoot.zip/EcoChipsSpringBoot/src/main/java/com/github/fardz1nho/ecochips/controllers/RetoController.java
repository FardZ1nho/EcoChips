package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.dtos.RetoDTO;
import com.github.fardz1nho.ecochips.entities.Reto;
import com.github.fardz1nho.ecochips.servicesinterfaces.IRetoService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/retos")
public class RetoController {
    @Autowired
    private IRetoService rService;

    @PostMapping
    public void insertar(@RequestBody RetoDTO dto){
        ModelMapper m = new ModelMapper();
        Reto r = m.map(dto, Reto.class);
        rService.insert(r);
    }

    @GetMapping
    public List<RetoDTO> listar(){
        return rService.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, RetoDTO.class);
        }).collect(Collectors.toList());
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id") Long id){
        rService.delete(id);
    }

    @GetMapping("/{id}")
    public RetoDTO listarId(@PathVariable("id") Long id){
        ModelMapper m = new ModelMapper();
        return m.map(rService.listId(id), RetoDTO.class);
    }
}