package com.github.fardz1nho.ecochips.repositories;

import com.github.fardz1nho.ecochips.entities.Recompensa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IRecompensaRepository extends JpaRepository<Recompensa, Integer> {
    List<Recompensa> findByCostoPuntos(int costoPuntos);
    List<Recompensa> findByTituloRecompensa(String tituloRecompensa);
}
