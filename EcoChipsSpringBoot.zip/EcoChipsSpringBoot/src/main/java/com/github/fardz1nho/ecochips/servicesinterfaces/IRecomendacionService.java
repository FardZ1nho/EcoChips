package com.github.fardz1nho.ecochips.servicesinterfaces;

import com.github.fardz1nho.ecochips.entities.Recomendacion;

import java.util.List;

public interface IRecomendacionService {

    List<Recomendacion> list();

    Recomendacion insert(Recomendacion recomendacion);

    Recomendacion update(Recomendacion recomendacion);

    void delete(int id);

    List<Recomendacion> findByTipo(String tipo);

    List<Recomendacion> findByTituloContaining(String titulo);

    List<Recomendacion> findByDescripcionContaining(String descripcion);
}