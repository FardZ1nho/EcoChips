package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.dtos.HuellaCarbonoDTO;
import com.github.fardz1nho.ecochips.entities.HuellaCarbono;
import com.github.fardz1nho.ecochips.servicesinterfaces.IHuellaCarbonoService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/huellacarbono")
public class HuellaCarbonoController {

    @Autowired
    private IHuellaCarbonoService huellaCarbonoService;

    @GetMapping
    public List<HuellaCarbonoDTO> listar() {
        return huellaCarbonoService.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, HuellaCarbonoDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody HuellaCarbonoDTO dto) {
        ModelMapper m = new ModelMapper();
        HuellaCarbono huellaCarbono = m.map(dto, HuellaCarbono.class);
        huellaCarbonoService.insert(huellaCarbono);
    }

    @PutMapping("/{idHuella}")
    public void modificar(@PathVariable("idHuella") int idHuella, @RequestBody HuellaCarbonoDTO dto) {
        dto.setIdHuella(idHuella);
        ModelMapper m = new ModelMapper();
        HuellaCarbono huellaCarbono = m.map(dto, HuellaCarbono.class);
        huellaCarbonoService.update(huellaCarbono);
    }

    @DeleteMapping("/{idHuella}")
    public void eliminar(@PathVariable("idHuella") Integer id) {
        huellaCarbonoService.delete(id);
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<HuellaCarbonoDTO> listarPorUsuario(
            @PathVariable("idUsuario") int idUsuario,
            @RequestParam(value = "fechaInicio", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
            @RequestParam(value = "fechaFin", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin,
            @RequestParam(value = "categoria", required = false) String categoria) {

        List<HuellaCarbono> huellas;

        if (fechaInicio != null && fechaFin != null && categoria != null) {
            huellas = huellaCarbonoService.findByUsuarioFechasAndCategoria(idUsuario, fechaInicio, fechaFin, categoria);
        } else if (fechaInicio != null && fechaFin != null) {
            huellas = huellaCarbonoService.findByUsuarioAndFechas(idUsuario, fechaInicio, fechaFin);
        } else if (categoria != null) {
            huellas = huellaCarbonoService.findByUsuarioAndCategoria(idUsuario, categoria);
        } else {
            huellas = huellaCarbonoService.findByUsuarioId(idUsuario);
        }

        return huellas.stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, HuellaCarbonoDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/categoria/{categoria}")
    public List<HuellaCarbonoDTO> listarPorCategoria(@PathVariable("categoria") String categoria) {
        return huellaCarbonoService.findByCategoria(categoria).stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, HuellaCarbonoDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/total/{idUsuario}")
    public Double obtenerTotalCO2(@PathVariable("idUsuario") int idUsuario) {
        return huellaCarbonoService.getTotalCO2ByUsuario(idUsuario);
    }

    @GetMapping("/total/{idUsuario}/categoria/{categoria}")
    public Double obtenerTotalCO2PorCategoria(@PathVariable("idUsuario") int idUsuario,
                                              @PathVariable("categoria") String categoria) {
        return huellaCarbonoService.getTotalCO2ByUsuarioAndCategoria(idUsuario, categoria);
    }
}