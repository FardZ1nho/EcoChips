package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.entities.Logro;
import com.github.fardz1nho.ecochips.servicesinterfaces.ILogroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/logros")
public class LogroController {
    @Autowired
    private ILogroService lService;

    @PostMapping
    public void insertar(@RequestBody Logro logro) {
        lService.insert(logro);
    }

    @GetMapping
    public List<Logro> listar() {
        return lService.list();
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id") Integer id) {
        lService.delete(id);
    }

    @GetMapping("/{id}")
    public Logro listarId(@PathVariable("id") Integer id) {
        return lService.listId(id);
    }
}
