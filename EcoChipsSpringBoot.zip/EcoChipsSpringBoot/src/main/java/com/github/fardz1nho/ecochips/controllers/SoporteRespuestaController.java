package com.github.fardz1nho.ecochips.controllers;

import com.github.fardz1nho.ecochips.entities.SoporteRespuesta;
import com.github.fardz1nho.ecochips.servicesinterfaces.ISoporteRespuestaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Service
public class SoporteRespuestaController {

    @Autowired
    private ISoporteRespuestaService service;

    @GetMapping
    public List<SoporteRespuesta> listarRespuestas() {
        return service.listarRespuestas();
    }

    @GetMapping("/{id}")
    public SoporteRespuesta obtenerRespuesta(@PathVariable int id) {
        return service.obtenerRespuestaPorId(id);
    }

    @PostMapping
    public SoporteRespuesta guardarRespuesta(@RequestBody SoporteRespuesta respuesta) {
        return service.guardarRespuesta(respuesta);
    }

    @DeleteMapping("/{id}")
    public void eliminarRespuesta(@PathVariable int id) {
        service.eliminarRespuesta(id);
    }
}
