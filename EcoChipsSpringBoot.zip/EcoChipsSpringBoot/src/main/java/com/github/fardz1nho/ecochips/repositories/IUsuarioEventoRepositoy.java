package com.github.fardz1nho.ecochips.repositories;

import com.github.fardz1nho.ecochips.entities.UsuarioEvento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface IUsuarioEventoRepositoy extends JpaRepository<UsuarioEvento,Integer>{
}
