package com.github.fardz1nho.ecochips.servicesinterfaces;

import com.github.fardz1nho.ecochips.entities.UsuarioRecomendacion;

import java.util.List;

public interface IUsuarioRecomendacionService {

    List<UsuarioRecomendacion> list();

    UsuarioRecomendacion insert(UsuarioRecomendacion usuarioRecomendacion);

    UsuarioRecomendacion update(UsuarioRecomendacion usuarioRecomendacion);

    void delete(int id);

    List<UsuarioRecomendacion> findByUsuarioId(int idUsuario);

    List<UsuarioRecomendacion> findByRecomendacionId(int idRecomenda);

    List<UsuarioRecomendacion> findByUsuarioAndTipo(int idUsuario, String tipo);

    UsuarioRecomendacion findByUsuarioAndRecomendacion(int idUsuario, int idRecomenda);

    Integer countRecomendacionesByUsuario(int idUsuario);

    Integer countByTipo(String tipo);
}