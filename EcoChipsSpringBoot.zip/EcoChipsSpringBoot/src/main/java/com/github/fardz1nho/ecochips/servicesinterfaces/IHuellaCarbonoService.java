package com.github.fardz1nho.ecochips.servicesinterfaces;

import com.github.fardz1nho.ecochips.entities.HuellaCarbono;

import java.time.LocalDate;
import java.util.List;

public interface IHuellaCarbonoService {

    List<HuellaCarbono> list();

    HuellaCarbono insert(HuellaCarbono huellaCarbono);

    HuellaCarbono update(HuellaCarbono huellaCarbono);

    void delete(int id);

    List<HuellaCarbono> findByUsuarioId(int idUsuario);

    List<HuellaCarbono> findByCategoria(String categoria);

    List<HuellaCarbono> findByUsuarioAndFechas(int idUsuario, LocalDate fechaInicio, LocalDate fechaFin);

    List<HuellaCarbono> findByUsuarioAndCategoria(int idUsuario, String categoria);

    List<HuellaCarbono> findByUsuarioFechasAndCategoria(int idUsuario, LocalDate fechaInicio, LocalDate fechaFin, String categoria);

    Double getTotalCO2ByUsuario(int idUsuario);

    Double getTotalCO2ByUsuarioAndCategoria(int idUsuario, String categoria);
}
