package com.github.fardz1nho.ecochips.servicesinterfaces;

import com.github.fardz1nho.ecochips.entities.UsuarioRecompensa;
import org.springframework.context.annotation.Bean;

import java.util.List;


public interface IUsuarioRecompensaService {
    public List<UsuarioRecompensa> list();
    public void insert(UsuarioRecompensa usuariorecompensa);
}
