package com.github.fardz1nho.ecochips.servicesinterfaces;


import com.github.fardz1nho.ecochips.entities.Reto;

import java.util.List;

public interface IRetoService {
    void insert(Reto reto);
    List<Reto>list();
    void delete(Long idReto);
    Reto listId(Long idReto);
}
