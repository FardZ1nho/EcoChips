package pe.edu.upc.demoeco3srpingboot.DTOs;

public class ResumenDTO {
    private String nombre;
    private int puntos;
    private int nivel;

    public ResumenDTO() {
    }

    public ResumenDTO(String nombre, int puntos, int nivel) {
        this.nombre = nombre;
        this.puntos = puntos;
        this.nivel = nivel;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }
}
