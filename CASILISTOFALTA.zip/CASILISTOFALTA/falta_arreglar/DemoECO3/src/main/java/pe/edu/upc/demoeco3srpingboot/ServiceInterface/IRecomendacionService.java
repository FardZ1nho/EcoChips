package pe.edu.upc.demoeco3srpingboot.ServiceInterface;

import pe.edu.upc.demoeco3srpingboot.Entities.Recomendacion;

import java.util.List;

public interface IRecomendacionService {
    public List<Recomendacion> list();
    public Recomendacion listId(int id);
    public void insert(Recomendacion recomendacion);
    public void delete(int id);
    public void update(Recomendacion recomendacion);
}
