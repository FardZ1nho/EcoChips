package pe.edu.upc.demoeco3srpingboot.DTOs;


import pe.edu.upc.demoeco3srpingboot.Entities.Evento;
import pe.edu.upc.demoeco3srpingboot.Entities.Usuario;

import java.time.LocalDate;

public class UsuarioEventoDTO {

    private int idUsuarioEvento;
    private int idUsuario;
    private int idEvento;
    private LocalDate fechaRegistro;

    public int getIdUsuarioEvento() {
        return idUsuarioEvento;
    }

    public void setIdUsuarioEvento(int idUsuarioEvento) {
        this.idUsuarioEvento = idUsuarioEvento;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public int getIdEvento() {return idEvento;}

    public void setIdEvento(int idEvento) {this.idEvento = idEvento;}

    public int getIdUsuario() {return idUsuario;}

    public void setIdUsuario(int idUsuario) {this.idUsuario = idUsuario;}
}