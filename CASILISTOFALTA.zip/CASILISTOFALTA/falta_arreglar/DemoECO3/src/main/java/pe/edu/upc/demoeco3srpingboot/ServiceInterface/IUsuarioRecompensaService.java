package pe.edu.upc.demoeco3srpingboot.ServiceInterface;

import pe.edu.upc.demoeco3srpingboot.Entities.Recompensa;
import pe.edu.upc.demoeco3srpingboot.Entities.UsuarioRecompensa;

import java.util.List;

public interface IUsuarioRecompensaService {
    public List<UsuarioRecompensa> list();
    public void insert(UsuarioRecompensa usuariorecompensa);
    public UsuarioRecompensa listId(int id);
    public void update(UsuarioRecompensa uR);
    public void delete(int id);
    public List<Recompensa> findRecompensasCanjeadasPorUsuario(int idUsuario);
    public List<String[]> findRecompensasMasCanjeadas();
}
