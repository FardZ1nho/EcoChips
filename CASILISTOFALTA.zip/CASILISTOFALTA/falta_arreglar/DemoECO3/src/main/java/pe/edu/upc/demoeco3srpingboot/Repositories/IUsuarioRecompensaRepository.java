package pe.edu.upc.demoeco3srpingboot.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.demoeco3srpingboot.Entities.Recompensa;
import pe.edu.upc.demoeco3srpingboot.Entities.UsuarioRecompensa;

import java.util.List;

@Repository
public interface IUsuarioRecompensaRepository extends JpaRepository<UsuarioRecompensa, Integer> {
    @Query("SELECT ur.recompensa FROM UsuarioRecompensa ur " +
            "WHERE ur.usuario.idUsuario = :idUsuario")
    List<Recompensa> findRecompensasCanjeadasPorUsuario(@Param("idUsuario") int idUsuario);

    @Query(value = "SELECT r.titulo_recompensa, r.descripcion_recompensa, r.costo_puntos, " +
            "COUNT(ur.id_usuario_recompensa) AS total_canjes " +
            "FROM usuario_recompensa ur " +
            "JOIN recompensa r ON ur.id_recompensa = r.id_recompensa " +
            "GROUP BY r.id_recompensa, r.titulo_recompensa, r.descripcion_recompensa, r.costo_puntos " +
            "ORDER BY total_canjes DESC", nativeQuery = true)
    List<String[]> findRecompensasMasCanjeadas();
}
