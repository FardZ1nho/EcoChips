package pe.edu.upc.demoeco3srpingboot.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.demoeco3srpingboot.DTOs.RecompensaDTO;
import pe.edu.upc.demoeco3srpingboot.DTOs.RecompensaPopularDTO;
import pe.edu.upc.demoeco3srpingboot.DTOs.UsuarioHabitoDTO;
import pe.edu.upc.demoeco3srpingboot.DTOs.UsuarioRecompensaDTO;
import pe.edu.upc.demoeco3srpingboot.Entities.Recompensa;
import pe.edu.upc.demoeco3srpingboot.Entities.UsuarioHabito;
import pe.edu.upc.demoeco3srpingboot.Entities.UsuarioRecompensa;
import pe.edu.upc.demoeco3srpingboot.Repositories.IUsuarioRecompensaRepository;
import pe.edu.upc.demoeco3srpingboot.ServiceInterface.IUsuarioRecompensaService;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/canjes")
public class UsuarioRecompensaController {
    @Autowired
    private IUsuarioRecompensaService urS;

    @GetMapping("/dtos")
    public List<UsuarioRecompensaDTO> list(){
        return urS.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y,UsuarioRecompensaDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody UsuarioRecompensaDTO dto)
    {
        ModelMapper m = new ModelMapper();
        UsuarioRecompensa ur =m.map(dto,UsuarioRecompensa.class);
        urS.insert(ur);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        UsuarioRecompensa uR = urS.listId(id);
        if (uR == null) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro con el ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        UsuarioRecompensaDTO dto = m.map(uR, UsuarioRecompensaDTO.class);
        return ResponseEntity.ok(dto);
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody UsuarioRecompensaDTO dto) {
        ModelMapper m = new ModelMapper();
        UsuarioRecompensa ur = m.map(dto, UsuarioRecompensa.class);

        UsuarioRecompensa existente = urS.listId(ur.getIdUsuarioRecompensa());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe un registro con el ID: " + ur.getIdUsuarioRecompensa());
        }

        urS.update(ur);
        return ResponseEntity.ok("Registro con ID " + ur.getIdUsuarioRecompensa() + " modificado correctamente.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        UsuarioRecompensa ur = urS.listId(id);
        if (ur == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro con el ID: " + id);
        }
        urS.delete(id);
        return ResponseEntity.ok("Registro con ID " + id + " eliminado correctamente.");

    }

    @GetMapping("/registro")
    public ResponseEntity<?> findRecompensasCanjeadasPorUsuario(@RequestParam("idUsuario") int idUsuario) {
        List<Recompensa> recompensas = urS.findRecompensasCanjeadasPorUsuario(idUsuario);

        if (recompensas.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("El usuario con id " + idUsuario + " no ha canjeado recompensas.");
        }

        List<RecompensaDTO> listaDTO = recompensas.stream().map(r -> {
            ModelMapper m = new ModelMapper();
            return m.map(r, RecompensaDTO.class);
        }).collect(Collectors.toList());

        return ResponseEntity.ok(listaDTO);
    }

    @GetMapping("/popular")
    public ResponseEntity<?> findRecompensasMasCanjeadas() {
        List<RecompensaPopularDTO> dtoLista=new ArrayList<>();
        List<String[]> fila = urS.findRecompensasMasCanjeadas();

        if (fila.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No hay recompensas registradas." );
        }
        for(String[]columna:fila){
            RecompensaPopularDTO dto=new RecompensaPopularDTO();
            dto.setTituloRecompensa(columna[0]);
            dto.setDescripcionRecompensa(columna[1]);
            dto.setCostoPuntos(Integer.parseInt(columna[2]));
            dto.setTotalCanjes(Integer.parseInt(columna[3]));
            dtoLista.add(dto);
        }
        return ResponseEntity.ok(dtoLista);
    }
}
