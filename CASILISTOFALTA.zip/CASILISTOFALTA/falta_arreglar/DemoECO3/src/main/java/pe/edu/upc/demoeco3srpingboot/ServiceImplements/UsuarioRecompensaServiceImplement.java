package pe.edu.upc.demoeco3srpingboot.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.demoeco3srpingboot.Entities.Recompensa;
import pe.edu.upc.demoeco3srpingboot.Entities.UsuarioRecompensa;
import pe.edu.upc.demoeco3srpingboot.Repositories.IUsuarioRecompensaRepository;
import pe.edu.upc.demoeco3srpingboot.ServiceInterface.IUsuarioRecompensaService;

import java.util.List;

@Service
public class UsuarioRecompensaServiceImplement implements IUsuarioRecompensaService {
    @Autowired
    private IUsuarioRecompensaRepository urS;

    @Override
    public List<UsuarioRecompensa> list() {return urS.findAll();}

    @Override
    public void insert(UsuarioRecompensa usuariorecompensa){urS.save(usuariorecompensa);}

    @Override
    public UsuarioRecompensa listId(int id) {return urS.findById(id).orElse(null);}

    @Override
    public void update(UsuarioRecompensa uR) {urS.save(uR);}

    @Override
    public void delete(int id) {urS.deleteById(id);}

    @Override
    public List<Recompensa> findRecompensasCanjeadasPorUsuario(int idUsuario) {return urS.findRecompensasCanjeadasPorUsuario(idUsuario);}

    @Override
    public List<String[]> findRecompensasMasCanjeadas() {return urS.findRecompensasMasCanjeadas();}
}
