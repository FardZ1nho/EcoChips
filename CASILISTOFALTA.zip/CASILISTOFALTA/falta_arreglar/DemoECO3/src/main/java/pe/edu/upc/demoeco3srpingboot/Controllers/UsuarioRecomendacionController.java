package pe.edu.upc.demoeco3srpingboot.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.demoeco3srpingboot.DTOs.UsuarioRecomendacionCreateDTO;
import pe.edu.upc.demoeco3srpingboot.DTOs.UsuarioRecomendacionDTO;
import pe.edu.upc.demoeco3srpingboot.Entities.Recomendacion;
import pe.edu.upc.demoeco3srpingboot.Entities.Usuario;
import pe.edu.upc.demoeco3srpingboot.Entities.UsuarioRecomendacion;
import pe.edu.upc.demoeco3srpingboot.ServiceInterface.IUsuarioRecomendacionService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/usuario-recomendacion")

public class UsuarioRecomendacionController {

    @Autowired
    private IUsuarioRecomendacionService urS;

    @PostMapping
    public void insert(@RequestBody UsuarioRecomendacionCreateDTO dto) {
        UsuarioRecomendacion ur = new UsuarioRecomendacion();

        Usuario usuario = new Usuario();
        usuario.setIdUsuario(dto.getIdUsuario());

        Recomendacion recomendacion = new Recomendacion();
        recomendacion.setIdRecomendacion(dto.getIdRecomendacion());

        ur.setUsuario(usuario);
        ur.setRecomendacion(recomendacion);
        ur.setFechaAsignacion(dto.getFechaAsignacion());

        urS.insert(ur);
    }

    @GetMapping("/dtos")
    public List<UsuarioRecomendacionDTO> list(){
        return urS.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y,UsuarioRecomendacionDTO.class);
        }).collect(Collectors.toList());
    }


    @GetMapping("/{idUsuario}")
    public ResponseEntity<?> listarRecomendacionesPorUsuario(@PathVariable("idUsuario") int idUsuario) {
        List<Recomendacion> recomendaciones = urS.findRecomendacionesPorUsuario(idUsuario);

        if (recomendaciones.isEmpty()) {
            return ResponseEntity.ok("No tienes recomendaciones asignadas");
        }

        return ResponseEntity.ok(recomendaciones);
    }

    @PutMapping("/actualizar")
    public ResponseEntity<String> modificar(@RequestBody UsuarioRecomendacionDTO dto) {
        ModelMapper m = new ModelMapper();
        UsuarioRecomendacion re = m.map(dto, UsuarioRecomendacion.class);

        UsuarioRecomendacion existente = urS.listId(re.getIdUsuarioRecomendacion());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe una reserva con el ID: " + re.getIdUsuarioRecomendacion());
        }
        urS.update(re);
        return ResponseEntity.ok("Reserva con ID " + re.getIdUsuarioRecomendacion() + " modificado correctamente.");
    }

    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        UsuarioRecomendacion t = urS.listId(id);
        if (t == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro con el ID: " + id);
        }
        urS.delete(id);
        return ResponseEntity.ok("Registro con ID " + id + " eliminado correctamente.");
    }


    @GetMapping("/filtrar")
    public ResponseEntity<?> filtrarPorTipo(@RequestParam("tipo") String tipo) {
        List<Recomendacion> resultados = urS.filtrarPorTipo(tipo);

        if (resultados.isEmpty()) {
            return ResponseEntity.ok("No se encontraron recomendaciones con ese filtro");
        }

        return ResponseEntity.ok(resultados);
    }

}
