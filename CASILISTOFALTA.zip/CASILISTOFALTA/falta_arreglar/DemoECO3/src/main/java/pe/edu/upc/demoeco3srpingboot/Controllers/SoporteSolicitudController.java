package pe.edu.upc.demoeco3srpingboot.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.demoeco3srpingboot.DTOs.SoporteSolicitudDTO;
import pe.edu.upc.demoeco3srpingboot.Entities.SoporteSolicitud;
import pe.edu.upc.demoeco3srpingboot.ServiceInterface.ISoporteSolicitudService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/soporte")
public class SoporteSolicitudController {
    @Autowired
    private ISoporteSolicitudService sR;

    @GetMapping
    public List<SoporteSolicitudDTO> listar() {
        return sR.list().stream().map(y->{
            ModelMapper m = new ModelMapper();
            return m.map(y,SoporteSolicitudDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody SoporteSolicitudDTO solicitud) {
        ModelMapper m = new ModelMapper();
        SoporteSolicitud so = m.map(solicitud, SoporteSolicitud.class);
        sR.insert(so);
    }
}