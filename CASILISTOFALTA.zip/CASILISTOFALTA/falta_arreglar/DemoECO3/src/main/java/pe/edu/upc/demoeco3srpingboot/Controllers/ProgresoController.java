package pe.edu.upc.demoeco3srpingboot.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.demoeco3srpingboot.DTOs.ProgresoDTO;
import pe.edu.upc.demoeco3srpingboot.DTOs.ResumenDTO;
import pe.edu.upc.demoeco3srpingboot.Entities.Progreso;
import pe.edu.upc.demoeco3srpingboot.ServiceInterface.IProgresoService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/progresos")
public class ProgresoController {

    @Autowired
    private IProgresoService progresoService;

    @GetMapping
    public List<ProgresoDTO> list() {
        return progresoService.list().stream().map(y -> {
            ModelMapper m = new ModelMapper();
            return m.map(y, ProgresoDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public String insertar(@RequestBody ProgresoDTO dto) {
        ModelMapper m = new ModelMapper();
        Progreso p = m.map(dto, Progreso.class);

        progresoService.insert(p);
        return "Registrado correctamente";
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Progreso dev = progresoService.listId(id);
        if (dev == null) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("No existe un progreso con el ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        ProgresoDTO dto = m.map(dev, ProgresoDTO.class);
        return ResponseEntity.ok(dto);
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody ProgresoDTO dto) {
        ModelMapper m = new ModelMapper();
        Progreso dev = m.map(dto, Progreso.class);

        Progreso existente = progresoService.listId(dev.getIdProgreso());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe un registro con el ID: " + dev.getIdProgreso());
        }

        progresoService.update(dev);
        return ResponseEntity.ok("Registro con ID " + dev.getIdProgreso() + " modificado correctamente.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        Progreso d = progresoService.listId(id);
        if (d == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro con el ID: " + id);
        }
        progresoService.delete(id);
        return ResponseEntity.ok("Registro con ID " + id + " eliminado correctamente.");
    }

    @GetMapping("/resumen/{idUsuario}")
    public ResumenDTO resumen(@PathVariable int idUsuario) {
        return progresoService.obtenerResumen(idUsuario);
    }
}