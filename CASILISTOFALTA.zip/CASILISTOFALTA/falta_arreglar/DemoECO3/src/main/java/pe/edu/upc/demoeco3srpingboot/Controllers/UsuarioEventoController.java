package pe.edu.upc.demoeco3srpingboot.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.demoeco3srpingboot.DTOs.ParticipacionRetoDTO;
import pe.edu.upc.demoeco3srpingboot.DTOs.UsuarioEventoDTO;
import pe.edu.upc.demoeco3srpingboot.Entities.UsuarioEvento;
import pe.edu.upc.demoeco3srpingboot.ServiceInterface.IUsuarioEventoService;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/usuario-evento")

public class UsuarioEventoController {

    @Autowired
    private IUsuarioEventoService ueS;


    @PostMapping
    public void insert(@RequestBody UsuarioEventoDTO dto) {
        ModelMapper m = new ModelMapper();
        UsuarioEvento h=m.map(dto, UsuarioEvento.class);
        ueS.insert(h);
    }

    @PutMapping("/actualizar")
    public ResponseEntity<String> modificar(@RequestBody UsuarioEventoDTO dto) {
        ModelMapper m = new ModelMapper();
        UsuarioEvento re = m.map(dto, UsuarioEvento.class);

        UsuarioEvento existente = ueS.listId(re.getIdUsuarioEvento());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe una reserva con el ID: " + re.getIdUsuarioEvento());
        }
        ueS.update(re);
        return ResponseEntity.ok("Reserva con ID " + re.getIdUsuarioEvento() + " modificado correctamente.");
    }

    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        UsuarioEvento t = ueS.listId(id);
        if (t == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un usuario evento con el ID: " + id);
        }
        ueS.delete(id);
        return ResponseEntity.ok("usuario evento con ID " + id + " eliminado correctamente.");
    }

    //GET (LISTAR)
    @GetMapping
    public List<UsuarioEventoDTO> listar() {
        return ueS.list().stream().map(x->{
            ModelMapper m = new ModelMapper();
            return m.map(x, UsuarioEventoDTO.class);
        }).collect(Collectors.toList());
    }

    @GetMapping("/totalEventos")
    public ResponseEntity<String> getTotalEventos(
            @RequestParam("fechaInicio") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
            @RequestParam("fechaFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin) {

        long total = ueS.contarEventosEnRango(fechaInicio, fechaFin);

        if(total == 0){
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se encontraron eventos en el rango de fechas proporcionado ("
                            + fechaInicio + " a " + fechaFin + ")");
        }

        return ResponseEntity.ok("Total de eventos encontrados entre "
                + fechaInicio + " y " + fechaFin + ": " + total);
    }


}
